<?php

namespace App\Http\Controllers\SiteMM\SiteOperation;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\SiteMM\Master\Employee;

use App\Models\SiteMM\SiteOperation\PaymentVoucher;
use App\Models\SiteMM\SiteOperation\PaymentVoucherDetail;

use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\MessageBag;
use Illuminate\Support\Carbon;

use App\Rules\ZeroValidation;
use App\Rules\CurrencyValidation;

class EmployeeAdvanceController extends Controller {

    public function loadView(){

        $data['employee'] = Employee::where('active', 1)->get();
        $data['attributes'] = $this->getEmployeeAdvanceAttributes(NULL, NULL);

        return view('SiteMM.SiteOperation.employee_advance')->with('EA', $data);
    }

    private function getEmployeeAdvanceAttributes($process, $request){

        $attributes['pv_id'] = '#Auto#';
        $attributes['pv_date'] = Carbon::today()->toDateString();
        $attributes['employee_id'] = '0';
        $attributes['advance_amount'] = '0';
        $attributes['remark'] = '';
        $attributes['pv_detail'] = array();
        $attributes['pv_total'] = 0;

        $attributes['validation_messages'] = new MessageBag();;
        $attributes['process_message'] = '';

        if( (is_null($request) == TRUE) && (is_null($process) == TRUE) ){

            return $attributes;
        }

        if( ($process['validation_result'] == TRUE) && ($process['process_status'] == TRUE)){

            $elqPv = PaymentVoucher::where('pv_id', $process['pv_id'] )->first();
            $elqPvDetail = PaymentVoucherDetail::where('pv_id', $process['pv_id'])->get();
            $pv_total = 0;

            foreach($elqPvDetail as $key => $value){

                $value->ono = ($key+1);
                $value->employee_name = Employee::where('employee_id', $value->employee_id)->value('employee_name');
                $pv_total = $pv_total + $value->amount;
            }

            $attributes['pv_id'] = $elqPv->pv_id;
            $attributes['pv_date'] = $elqPv->pv_date;
            $attributes['cs_id'] = 2;
            $attributes['remark'] = $elqPv->remark;
            $attributes['pv_detail'] = $elqPvDetail;
            $attributes['pv_total'] = $elqPvDetail->sum('amount');

            $attributes['validation_messages'] = $process['validation_messages'];

            if($request->submit == 'Display'){

                $attributes['validation_messages'] = new MessageBag();
                $attributes['process_message'] = "";
            }else{

                $message = $process['front_end_message'] .' <br> ' . $process['back_end_message'];
                $attributes['process_message'] = '<div class="alert alert-success" role="alert"> '. $message .' </div> ';
            }

        }else{

            $inputs = $request->input();
            if(is_null($inputs) == FALSE){

                $attributes['pv_id'] = $inputs['pv_id'];
                $attributes['pv_date'] = $inputs['pv_date'];
                $attributes['employee_id'] = $inputs['employee_id'];
                $attributes['advance_amount'] = $inputs['advance_amount'];
                $attributes['remark'] = $inputs['remark'];
            }

            $pv_total = 0;
            $elqPvDetail = PaymentVoucherDetail::where('pv_id', $request->pv_id)->get();
            foreach($elqPvDetail as $key => $value){

                $value->ono = ($key+1);
                $value->employee_name = Employee::where('employee_id', $value->employee_id)->value('employee_name');
                $pv_total = $pv_total + $value->amount;
            }

            $attributes['pv_detail'] = $elqPvDetail;
            $attributes['pv_total'] = $elqPvDetail->sum('amount');
            $attributes['validation_messages'] = $process['validation_messages'];

			$message = $process['front_end_message'] .' <br> ' . $process['back_end_message'];
            $attributes['process_message'] = '<div class="alert alert-danger" role="alert"> '. $message .' </div> ';
        }

        return $attributes;
    }

    public function processEmployeeAdvance(Request $request){

        if($request->submit == 'Add'){

            $pv_validation_result = $this->validatePaymentVoucher($request);

            if($pv_validation_result['validation_result'] == TRUE){

                $saving_process_result = $this->addPaymentVoucher($request);
                $saving_process_result['validation_result'] = $pv_validation_result['validation_result'];
                $saving_process_result['validation_messages'] = $pv_validation_result['validation_messages'];
                $data['attributes'] = $this->getEmployeeAdvanceAttributes($saving_process_result, $request);

            }else{

                $pv_validation_result['process_status'] = FALSE;
                $data['attributes'] = $this->getEmployeeAdvanceAttributes($pv_validation_result, $request);
            }
        }

        $data['employee'] = Employee::where('active', 1)->get();

        return view('SiteMM.SiteOperation.employee_advance')->with('EA', $data);
    }

    private function validatePaymentVoucher($request){

        //try{

            $inputs['pv_id'] = $request->pv_id;
            $inputs['pv_date'] = $request->pv_date;
            $inputs['employee_id'] = $request->employee_id;
            $inputs['advance_amount'] = $request->advance_amount;
            $inputs['remark'] = $request->remark;

            $rules['pv_id'] = array('required');
            $rules['pv_date'] = array('required', 'date');
            $rules['employee_id'] = array( new ZeroValidation('Employee', $request->employee_id));
            $rules['advance_amount'] = array('required', 'numeric', new CurrencyValidation(1));
            $rules['remark'] = array( 'max:100');

            $front_end_message = '';

            $validator = Validator::make($inputs, $rules);
            $validation_result = $validator->passes();
            if($validation_result == FALSE){

                $front_end_message = 'Please Check Your Inputs';
            }

            $process_result['validation_result'] = $validator->passes();
            $process_result['validation_messages'] =  $validator->errors();
            $process_result['front_end_message'] = $front_end_message;
            $process_result['back_end_message'] =  'Site Controller - Validation Process ';

            return $process_result;

        // }catch(\Exception $e){

        //     $process_result['validation_result'] = FALSE;
        //     $process_result['validation_messages'] = new MessageBag();
        //     $process_result['front_end_message'] =  $e->getMessage();
        //     $process_result['back_end_message'] =  'Site Controller - Validation Function Fault';

		// 	return $process_result;
        // }
    }

    private function addPaymentVoucher($request){

        //try{

            $objPaymentVoucher = new PaymentVoucher();

            $pv['pv'] = $this->getPaymentVoucherArray($request);
            $pv['pv_detail'] = $this->getPaymentVoucherDetailArray($request);
            $saving_process_result = $objPaymentVoucher->savePaymentVoucher($pv);

            return $saving_process_result;

        // }catch(\Exception $e){

        //     $process_result['site_id'] = $request->site_id;
        //     $process_result['process_status'] = FALSE;
        //     $process_result['front_end_message'] = $e->getMessage();
        //     $process_result['back_end_message'] = 'Site Controller -> Site Saving Process <br> ' . $e->getLine();

        //     return $process_result;
        // }
    }

    private function getPaymentVoucherArray($request){

        $pv['pv_id'] = $request->pv_id;
        $pv['pv_date'] = $request->pv_date;
        $pv['site_id'] = 0;
        $pv['task_id'] = 0;
        $pv['sub_task_id'] = 0;
        $pv['cs_id'] = 2;
        $pv['advance'] = 1;
        $pv['total_amount'] = 0;
        $pv['remark'] = $request->remark;

        if( $request->pv_id == '#Auto#' ){

            $pv['saved_by'] = Auth::id();
            $pv['saved_on'] = Carbon::now()->format('Y-m-d H:i:s');

        }else{

            $pv['updated_by'] = Auth::id();
            $pv['updated_on'] = Carbon::now()->format('Y-m-d H:i:s');
        }

        return $pv;
    }

    private function getPaymentVoucherDetailArray($request){

        $pv_detail['pv_id'] = 0;
        $pv_detail['oci_id'] = 0;
        $pv_detail['employee_id'] = $request->employee_id;
        $pv_detail['price'] = str_replace(",","",$request->advance_amount);
        $pv_detail['quantity'] = 1;
        $pv_detail['amount'] = floatval(str_replace(",","",$request->advance_amount)) * 1;

        if($request->pv_id == '#Auto#'){

            $pv_detail['saved_by'] = Auth::id();
            $pv_detail['saved_on'] = Carbon::now()->format('Y-m-d H:i:s');
        }else{

            $pv_detail['saved_by'] = Auth::id();
            $pv_detail['saved_on'] = Carbon::now()->format('Y-m-d H:i:s');
        }

        return $pv_detail;
    }

}
