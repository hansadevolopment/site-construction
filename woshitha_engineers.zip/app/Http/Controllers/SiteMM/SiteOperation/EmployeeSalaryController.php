<?php

namespace App\Http\Controllers\SiteMM\SiteOperation;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\SiteMM\Master\Employee;
use App\Models\SiteMM\Master\Site;

use App\Models\SiteMM\SiteForcast\SiteTask;
use App\Models\SiteMM\SiteForcast\SiteSubTask;
use App\Models\SiteMM\SiteOperation\PaymentVoucher;
use App\Models\SiteMM\SiteOperation\PaymentVoucherDetail;

use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\MessageBag;
use Illuminate\Support\Carbon;
use Carbon\CarbonPeriod;

use App\Rules\ZeroValidation;
use App\Rules\CurrencyValidation;

class EmployeeSalaryController extends Controller {

    public function loadView(){

        $data['employee'] = Employee::where('active', 1)->get();
        $data['attributes'] = $this->getEmployeeSalaryAttributes(NULL, NULL);

        return view('SiteMM.SiteOperation.employee_salary')->with('ES', $data);
    }

    private function getEmployeeSalaryAttributes($process, $request){

        $attributes['pv_id'] = '#Auto#';
        $attributes['pv_date'] = Carbon::today()->toDateString();
        $attributes['employee_id'] = '0';
        $attributes['salary_amount'] = '0';
        $attributes['remark'] = '';
        $attributes['salary_detail'] = array();
        $attributes['pv_detail'] = array();
        $attributes['pv_total'] = 0;

        $attributes['validation_messages'] = new MessageBag();;
        $attributes['process_message'] = '';

        if( (is_null($request) == TRUE) && (is_null($process) == TRUE) ){

            return $attributes;
        }

        if( ($process['validation_result'] == TRUE) && ($process['process_status'] == TRUE)){

            $elqPv = PaymentVoucher::where('pv_id', $process['pv_id'] )->first();
            $elqPvDetail = PaymentVoucherDetail::where('pv_id', $process['pv_id'])->get();
            $pv_total = 0;

            $attributes['pv_id'] = $elqPv->pv_id;
            $attributes['pv_date'] = $elqPv->pv_date;
            $attributes['remark'] = $elqPv->remark;
            $attributes['pv_detail'] = $elqPvDetail;
            $attributes['salary_detail'] = $this->getSalaryDetail($request);
            $attributes['pv_total'] = $elqPvDetail->sum('amount');

            $attributes['validation_messages'] = $process['validation_messages'];

            if($request->submit == 'Display'){

                $attributes['validation_messages'] = new MessageBag();
                $attributes['process_message'] = "";
            }else{

                $message = $process['front_end_message'] .' <br> ' . $process['back_end_message'];
                $attributes['process_message'] = '<div class="alert alert-success" role="alert"> '. $message .' </div> ';
            }

        }else{

            $inputs = $request->input();
            if(is_null($inputs) == FALSE){

                $attributes['pv_id'] = $inputs['pv_id'];
                $attributes['pv_date'] = $inputs['pv_date'];
                $attributes['employee_id'] = $inputs['employee_id'];
                $attributes['from_date'] = $inputs['from_date'];
                $attributes['to_date'] = $inputs['to_date'];
                $attributes['remark'] = $inputs['remark'];
            }

            if($request->submit == 'Display'){

                $attributes['salary_detail'] = $this->getSalaryDetail($request);
                $attributes['validation_messages'] = new MessageBag();
                $attributes['process_message'] = "";

            }else{

                $pv_total = 0;
                $elqPvDetail = PaymentVoucherDetail::where('pv_id', $request->pv_id)->get();

                $attributes['pv_detail'] = $elqPvDetail;
                $attributes['pv_total'] = $elqPvDetail->sum('amount');
                $attributes['validation_messages'] = $process['validation_messages'];

                $message = $process['front_end_message'] .' <br> ' . $process['back_end_message'];
                $attributes['process_message'] = '<div class="alert alert-danger" role="alert"> '. $message .' </div> ';
            }
        }

        return $attributes;
    }

    public function processEmployeeSalary(Request $request){

        if($request->submit == 'Display'){

            $pv_validation_result = $this->validateSalaryInput($request);

            if($pv_validation_result['validation_result'] == TRUE){

                $pv_validation_result['process_status'] = NULL;
                $data['attributes'] = $this->getEmployeeSalaryAttributes($pv_validation_result, $request);

            }else{

                $pv_validation_result['process_status'] = FALSE;
                $data['attributes'] = $this->getEmployeeSalaryAttributes($pv_validation_result, $request);
            }
        }

        if($request->submit == 'Save'){

            $pv_validation_result = $this->validateSalaryInput($request);
            if($pv_validation_result['validation_result'] == TRUE){

                $saving_process_result = $this->addPaymentVoucher($request);
                $saving_process_result['validation_result'] = $pv_validation_result['validation_result'];
                $saving_process_result['validation_messages'] = $pv_validation_result['validation_messages'];
                $data['attributes'] = $this->getEmployeeSalaryAttributes($saving_process_result, $request);

            }else{

                $pv_validation_result['process_status'] = FALSE;
                $data['attributes'] = $this->getEmployeeSalaryAttributes($pv_validation_result, $request);
            }

        }

        $data['employee'] = Employee::where('active', 1)->get();
        $data['site'] = Site::where('active', 1)->get();
        $data['site_task'] = SiteTask::where('active', 1)->where('site_id', $request->site_id)->get();
        $data['site_sub_task'] = SiteSubTask::where('active', 1)->where('task_id', $request->task_id)->get();

        return view('SiteMM.SiteOperation.employee_salary')->with('ES', $data);
    }

    private function getSalaryDetail($request){

        $period = CarbonPeriod::create($request->from_date, $request->to_date);
        $salary_detail = array();
        $basic_salary = Employee::where('employee_id', $request->employee_id)->first()->laborCategory->price;

        $icount = 1;
        foreach ($period as $date) {

            $advance_amount = 0;

            $elqPaymentVoucher = PaymentVoucher::where('pv_date', $date->format('Y-m-d'))->where('cs_id', 2)->where('advance', 1)->first();
            if( is_null($elqPaymentVoucher) == FALSE ){

                $elqAdvance = $elqPaymentVoucher->paymentVoucherDetail->where('employee_id', $request->employee_id);
                foreach($elqAdvance as $key => $value){

                    $advance_amount = $value->amount;
                }
            }

            $salary_detail[$icount]['ono'] = $icount;
            $salary_detail[$icount]['date'] =  $date->format('Y-F-d');
            $salary_detail[$icount]['date_serial'] =  $date->format('Ymd');
            $salary_detail[$icount]['basic_salary'] = number_format($basic_salary, 2);
            $salary_detail[$icount]['advance_amount'] = number_format($advance_amount, 2);
            $salary_detail[$icount]['ot_rate'] = number_format(($basic_salary / 8), 2);
            $salary_detail[$icount]['ot_hours'] = 0;
            $salary_detail[$icount]['ot_amount'] = number_format((($basic_salary / 8) * 0), 2);
            $salary_detail[$icount]['net_salary'] = number_format(($basic_salary - $advance_amount), 2);

            $icount++;
        }

        return $salary_detail;
    }

    private function validateSalaryInput($request){

        //try{

            $inputs['pv_id'] = $request->pv_id;
            $inputs['pv_date'] = $request->pv_date;
            $inputs['employee_id'] = $request->employee_id;
            $inputs['from_date'] = $request->from_date;
            $inputs['to_date'] = $request->to_date;
            $inputs['remark'] = $request->remark;

            $rules['pv_id'] = array('required');
            $rules['pv_date'] = array('required', 'date');
            $rules['employee_id'] = array( new ZeroValidation('Employee', $request->employee_id));
            $rules['from_date'] = array('required', 'date');
            $rules['to_date'] = array('required', 'date');
            $rules['remark'] = array( 'max:100');

            if($request->submit == 'Save'){

                $request_inputs = $request->all();
                foreach($request_inputs as $input_key => $input_value){

                    if( substr($input_key, 0, 8) == 'site_id_' ){

                        $inputs['site_id_' . substr($input_key, 8, 8)] = $request->input_value;
                        $rules['site_id_' . substr($input_key, 8, 8)] = array( new ZeroValidation('Site', $input_value));
                    }

                    if( substr($input_key, 0, 8) == 'task_id_' ){

                        $inputs['task_id_' . substr($input_key, 8, 8)] = $request->input_value;
                        $rules['task_id_' . substr($input_key, 8, 8)] = array( new ZeroValidation('Task', $input_value));
                    }

                    if( substr($input_key, 0, 12) == 'sub_task_id_' ){

                        $inputs['sub_task_id_' . substr($input_key, 12, 8)] = $request->input_value;
                        $rules['sub_task_id_' . substr($input_key, 12, 8)] = array( new ZeroValidation('Sub Task', $input_value));
                    }
                }
            }

            $front_end_message = '';

            $validator = Validator::make($inputs, $rules);
            $validation_result = $validator->passes();
            if($validation_result == FALSE){

                $front_end_message = 'Please Check Your Inputs';
            }

            $process_result['validation_result'] = $validator->passes();
            $process_result['validation_messages'] =  $validator->errors();
            $process_result['front_end_message'] = $front_end_message;
            $process_result['back_end_message'] =  'Employee Salary Controller - Validation Process ';

            //dd($process_result);

            return $process_result;

        // }catch(\Exception $e){

        //     $process_result['validation_result'] = FALSE;
        //     $process_result['validation_messages'] = new MessageBag();
        //     $process_result['front_end_message'] =  $e->getMessage();
        //     $process_result['back_end_message'] =  'Employee Salary Controller - Validation Function Fault';

		// 	return $process_result;
        // }
    }

    private function addPaymentVoucher($request){

        //try{

            $objPaymentVoucher = new PaymentVoucher();

            $pv['pv'] = $this->getPaymentVoucherArray($request);
            $pv['pv_detail'] = $this->getPaymentVoucherDetailArray($request);
            $saving_process_result = $objPaymentVoucher->savePaymentVoucher($pv);

            return $saving_process_result;

        // }catch(\Exception $e){

        //     $process_result['site_id'] = $request->site_id;
        //     $process_result['process_status'] = FALSE;
        //     $process_result['front_end_message'] = $e->getMessage();
        //     $process_result['back_end_message'] = 'Site Controller -> Site Saving Process <br> ' . $e->getLine();

        //     return $process_result;
        // }
    }

    private function getPaymentVoucherArray($request){

        $pv['pv_id'] = $request->pv_id;
        $pv['pv_date'] = $request->pv_date;
        $pv['site_id'] = $request->site_id;
        $pv['task_id'] = $request->task_id;
        $pv['sub_task_id'] = $request->sub_task_id;
        $pv['total_amount'] = 0;
        $pv['remark'] = $request->remark;

        if( $request->pv_id == '#Auto#' ){

            $pv['saved_by'] = Auth::id();
            $pv['saved_on'] = Carbon::now()->format('Y-m-d H:i:s');

        }else{

            $pv['updated_by'] = Auth::id();
            $pv['updated_on'] = Carbon::now()->format('Y-m-d H:i:s');
        }

        return $pv;
    }

    private function getPaymentVoucherDetailArray($request){

        $pv_detail['pv_id'] = 0;
        $pv_detail['oci_id'] = $request->oci_id;
        $pv_detail['price'] = str_replace(",","",$request->value);
        $pv_detail['quantity'] = 1;
        $pv_detail['amount'] = floatval(str_replace(",","",$request->value)) * 1;

        if($request->pv_id == '#Auto#'){

            $pv_detail['saved_by'] = Auth::id();
            $pv_detail['saved_on'] = Carbon::now()->format('Y-m-d H:i:s');
        }else{

            $pv_detail['saved_by'] = Auth::id();
            $pv_detail['saved_on'] = Carbon::now()->format('Y-m-d H:i:s');
        }

        return $pv_detail;
    }

    private function getEmployeeSalaryArray($request){

        $employee_salary['es_date'] = $request->pv_date;
        $employee_salary['employee_id'] = $request->employee_id;
        $employee_salary['pv_id'] = $request->pv_id;

        $employee_salary['site_id'] = $request->employee_id;
        $employee_salary['task_id'] = $request->employee_id;
        $employee_salary['sub_task_id'] = $request->employee_id;
        $employee_salary['gross_salary'] = $request->employee_id;
        $employee_salary['advance_amount'] = $request->employee_id;
        $employee_salary['ot_rate'] = $request->employee_id;
        $employee_salary['ot_hours'] = $request->employee_id;
        $employee_salary['ot_amount'] = $request->employee_id;
        $employee_salary['net_salary'] = $request->employee_id;
        $employee_salary['saved_by'] = $request->employee_id;
        $employee_salary['saved_on'] = $request->employee_id;
        $employee_salary['updated_by'] = $request->employee_id;
        $employee_salary['updated_on'] = $request->employee_id;

    }



}
