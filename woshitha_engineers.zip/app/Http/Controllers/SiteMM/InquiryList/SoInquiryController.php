<?php

namespace App\Http\Controllers\SiteMM\InquiryList;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class SoInquiryController extends Controller
{
    //
}
