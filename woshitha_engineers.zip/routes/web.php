<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use App\Http\Controllers\SiteMM\Master\SiteController;
use App\Http\Controllers\SiteMM\Master\ItemController;
use App\Http\Controllers\SiteMM\Master\LabourCategoryController;
use App\Http\Controllers\SiteMM\Master\EmployeeController;
use App\Http\Controllers\SiteMM\Master\OverheadCostController;
use App\Http\Controllers\SiteMM\Master\UnitController;

use App\Http\Controllers\SiteMM\SiteForcast\SiteTaskController;
use App\Http\Controllers\SiteMM\SiteForcast\SiteSubTaskController;
use App\Http\Controllers\SiteMM\SiteForcast\SiteMaterialsController;
use App\Http\Controllers\SiteMM\SiteForcast\SiteLabourController;
use App\Http\Controllers\SiteMM\SiteForcast\SiteOverheadCostController;
use App\Http\Controllers\SiteMM\SiteForcast\SiteProfitController;

use App\Http\Controllers\SiteMM\SiteOperation\ItemIssueNoteController;
use App\Http\Controllers\SiteMM\SiteOperation\PaymentVoucherController;
use App\Http\Controllers\SiteMM\SiteOperation\EmployeeAdvanceController;
use App\Http\Controllers\SiteMM\SiteOperation\EmployeeSalaryController;
use App\Http\Controllers\SiteMM\SiteOperation\EmployeeAttendanceOverTimeController;

use App\Http\Controllers\SiteMM\InquiryList\MasterInquiryController;
use App\Http\Controllers\SiteMM\InquiryList\SiteTaskSubTaskController;
use App\Http\Controllers\SiteMM\InquiryList\SapInquiryController;
use App\Http\Controllers\SiteMM\InquiryList\SoInquiryController;


Route::get('/', function () {

    return view('welcome');
});

Route::get('/dashboard', function () {

    return view('SiteMM.site_dashboard');
})->middleware(['auth'])->name('dashboard');


require __DIR__.'/auth.php';

/*
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
| Site Monitoring Module Routes
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
*/

/*------------------------------------------------------------- Site Master -------------------------------------------------------------*/

Route::get('/site', [SiteController::class, 'loadView'])->name('site');
Route::post('/site_process', [SiteController::class, 'processSite'])->name('site_process');
Route::get('/get_site_wise_task', [SiteController::class, 'getSiteWiseTask'])->name('get_site_wise_task');
Route::post('/open_site', [SiteController::class, 'openSite'])->name('open_site');
Route::get('/site_excel', [SiteController::class, 'getExcel'])->name('site_excel');

Route::get('/item', [ItemController::class, 'loadView'])->name('item');
Route::post('/item_process', [ItemController::class, 'processItem'])->name('item_process');
Route::get('/get_item_for_sap_material', [ItemController::class, 'getItemForSapMaterial'])->name('get_item_for_sap_material');
Route::post('/open_item', [ItemController::class, 'openItem'])->name('open_item');

Route::get('/labour_category', [LabourCategoryController::class, 'loadView'])->name('labour_category');
Route::post('/labour_category_process', [LabourCategoryController::class, 'procesLlabourCategory'])->name('labour_category_process');
Route::get('/get_labour_category_for_sap_labour', [LabourCategoryController::class, 'getLabourCategoryForSapLabour'])->name('get_labour_category_for_sap_labour');
Route::post('/open_labour_category', [LabourCategoryController::class, 'openLabourCategory'])->name('open_labour_category');

Route::get('/employee', [EmployeeController::class, 'loadView'])->name('employee');
Route::post('/employee_process', [EmployeeController::class, 'processEmployee'])->name('employee_process');
Route::get('/get_employee', [EmployeeController::class, 'getEmployee'])->name('get_employee');
Route::post('/open_employee', [EmployeeController::class, 'openEmployee'])->name('open_employee');

Route::get('/overhead_cost', [OverheadCostController::class, 'loadView'])->name('overhead_cost');
Route::post('/overhead_cost_process', [OverheadCostController::class, 'processOverheadCost'])->name('overhead_cost_process');
Route::post('/open_overhead', [OverheadCostController::class, 'openOverhead'])->name('open_overhead');

Route::get('/unit', [UnitController::class, 'loadView'])->name('unit');
Route::post('/unit_process', [UnitController::class, 'processUnit'])->name('unit_process');
Route::post('/open_unit', [UnitController::class, 'openUnit'])->name('open_unit');

/*------------------------------------------------------------- Site Forcasting -------------------------------------------------------------*/

Route::get('/site_task', [SiteTaskController::class, 'loadView'])->name('site_task');
Route::post('/site_task_process', [SiteTaskController::class, 'processSiteTask'])->name('site_task_process');
Route::get('/get_site_wise_sub_task', [SiteTaskController::class, 'getTaskWiseSubTask'])->name('get_site_wise_sub_task');
Route::post('/open_task', [SiteTaskController::class, 'openTask'])->name('open_task');

Route::get('/site_sub_task', [SiteSubTaskController::class, 'loadView'])->name('site_sub_task');
Route::post('/site_sub_task_process', [SiteSubTaskController::class, 'processSiteSubTask'])->name('site_sub_task_process');
Route::post('/open_sub_task', [SiteSubTaskController::class, 'openSubTask'])->name('open_sub_task');

Route::get('/sap_material', [SiteMaterialsController::class, 'loadView'])->name('sap_material');
Route::post('/sap_material_add_process', [SiteMaterialsController::class, 'addSapMaterial'])->name('sap_material_add_process');
Route::post('/open_sap_material', [SiteMaterialsController::class, 'openSapMaterial'])->name('open_sap_material');

Route::get('/sap_labour', [SiteLabourController::class, 'loadView'])->name('sap_labour');
Route::post('/sap_labour_add_process', [SiteLabourController::class, 'addSapLabour'])->name('sap_labour_add_process');
Route::post('/open_sap_labour', [SiteLabourController::class, 'openSapLabour'])->name('open_sap_labour');

Route::get('/sap_overhead', [SiteOverheadCostController::class, 'loadView'])->name('sap_overhead');
Route::post('/sap_overhead_add_process', [SiteOverheadCostController::class, 'addSapOverheadcost'])->name('sap_overhead_add_process');
Route::post('/open_sap_overhead', [SiteOverheadCostController::class, 'openSapOverhead'])->name('open_sap_overhead');

Route::get('/sap_profit', [SiteProfitController::class, 'loadView'])->name('sap_profit');
Route::post('/sap_profit_add_process', [SiteProfitController::class, 'addSapProfit'])->name('sap_profit_add_process');
Route::get('/sap_profit_total', [SiteProfitController::class, 'getSiteWiseTotalCost'])->name('sap_profit_total');
Route::post('/open_sap_profit', [SiteProfitController::class, 'openSapProfit'])->name('open_sap_profit');

/*------------------------------------------------------------- Site Operation -------------------------------------------------------------*/
Route::get('/item_issue_note', [ItemIssueNoteController::class, 'loadView'])->name('item_issue_note');
Route::post('/item_issue_note_process', [ItemIssueNoteController::class, 'processItemIssueNote'])->name('item_issue_note_process');

Route::get('/payment_voucher', [PaymentVoucherController::class, 'loadView'])->name('payment_voucher');
Route::post('/payment_voucher_process', [PaymentVoucherController::class, 'processPaymentVoucher'])->name('payment_voucher_process');

Route::get('/employee_advance', [EmployeeAdvanceController::class, 'loadView'])->name('employee_advance');
Route::post('/employee_advance_process', [EmployeeAdvanceController::class, 'processEmployeeAdvance'])->name('employee_advance_process');

Route::get('/employee_attendance', [EmployeeAttendanceOverTimeController::class, 'loadView'])->name('employee_attendance');
Route::post('/employee_attendance_process', [EmployeeAttendanceOverTimeController::class, 'processEmployeeAttendanceOvertime'])->name('employee_attendance_process');

Route::get('/employee_salary', [EmployeeSalaryController::class, 'loadView'])->name('employee_salary');
Route::post('/employee_salary_process', [EmployeeSalaryController::class, 'processEmployeeSalary'])->name('employee_salary_process');

/*------------------------------------------------------------- Inquiry & List -------------------------------------------------------------*/
Route::get('/master_inquire', [MasterInquiryController::class, 'loadView'])->name('master_inquire');
Route::post('/master_inquire_process', [MasterInquiryController::class, 'inquireMaster'])->name('master_inquire_process');

Route::get('/site_task_subtask_inquiry', [SiteTaskSubTaskController::class, 'loadView'])->name('site_task_subtask_inquiry');
Route::post('/site_task_subtask_inquiry_process', [SiteTaskSubTaskController::class, 'processSiteTaskSubTaskInquire'])->name('site_task_subtask_inquiry_process');

Route::get('/sap_inquire', [SapInquiryController::class, 'loadView'])->name('sap_inquire');
Route::post('/sap_inquire_process', [SapInquiryController::class, 'inquireSiteActionPlan'])->name('sap_inquire_process');

Route::get('/so_inquire', [SoInquiryController::class, 'loadView'])->name('so_inquire');
Route::post('/so_inquire_process', [SoInquiryController::class, 'inquireSiteOperation'])->name('so_inquire_process');
