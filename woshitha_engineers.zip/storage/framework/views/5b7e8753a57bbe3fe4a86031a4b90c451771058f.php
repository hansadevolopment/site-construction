<?php $__env->startSection('title'); ?>
    Employee Salary
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>

    <div class="row">
        <div class="col-12">
            <form method="POST" action="<?php echo e(route('employee_salary_process')); ?>">
                <?php echo csrf_field(); ?>

                <div class="card mt-3">

                    <div class="card-header">
                        Employee Salary
                    </div>

                    <div class="card-body">

                        <div class="row">
                            <div class="col-sm-12">
                                <?php echo $ES['attributes']['process_message'];  ?>
                            </div>
                        </div>

                        <div class="row no-gutters">
                            <div class="col-12 col-sm-12 col-md-12">

                                <div class="row mb-2">

                                    <div class="col-sm-9">
                                    </div>

                                    <label for="tid" class="col-sm-1 col-form-label-sm">PV No</label>
                                    <div class="col-sm-2">
                                        <input type="text" name="pv_id" id="pv_id" class="form-control form-control-sm" value="<?php echo e($ES['attributes']['pv_id']); ?>" readonly>
                                    </div>

                                </div>


                                <div class="row mb-2">

                                    <label for="tid" class="col-sm-1 col-form-label-sm">Employee</label>
                                    <div class="col-sm-5">
                                        <select name="employee_id" id="employee_id" class="form-select form-select-sm" >
                                            <?php $__currentLoopData = $ES['employee']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($ES['attributes']['employee_id'] == $row->employee_id): ?>
                                                    <option value ="<?php echo e($row->employee_id); ?>" selected><?php echo e($row->employee_name); ?></option>
                                                <?php else: ?>
                                                    <option value ="<?php echo e($row->employee_id); ?>"><?php echo e($row->employee_name); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($ES['attributes']['employee_id'] == "0"): ?>
                                                <option value ="0" selected>Select the Employee </option>
                                            <?php endif; ?>
                                        </select>
                                        <?php if($ES['attributes']['validation_messages']->has('employee_id')): ?>
                                            <script>
                                                    document.getElementById('employee_id').className = 'form-select form-select-sm is-invalid';
                                            </script>
                                            <div class="invalid-feedback"><?php echo e($ES['attributes']['validation_messages']->first("employee_id")); ?></div>
                                        <?php endif; ?>
                                    </div>

                                    <div class="col-sm-3">
                                    </div>

                                    <label for="tid" class="col-sm-1 col-form-label-sm">PV Date</label>
                                    <div class="col-sm-2">
                                        <input type="date" name="pv_date" id="pv_date" class="form-control form-control-sm" value="<?php echo e($ES['attributes']['pv_date']); ?>">
                                    </div>

                                </div>

                                <div class="row mb-2">
                                    <label for="tid" class="col-sm-1 col-form-label-sm">From Date</label>
                                    <div class="col-sm-2">
                                        <input type="date" name="from_date" id="from_date" class="form-control form-control-sm" value="<?php echo e($ES['attributes']['from_date']); ?>">
                                        <?php if($ES['attributes']['validation_messages']->has('from_date')): ?>
                                            <script>
                                                    document.getElementById('from_date').className = 'form-control form-control-sm is-invalid';
                                            </script>
                                            <div class="invalid-feedback"><?php echo e($ES['attributes']['validation_messages']->first("from_date")); ?></div>
                                        <?php endif; ?>
                                    </div>
                                    <label for="tid" class="col-sm-1 col-form-label-sm">To Date</label>
                                    <div class="col-sm-2">
                                        <input type="date" name="to_date" id="to_date" class="form-control form-control-sm" value="<?php echo e($ES['attributes']['to_date']); ?>">
                                        <?php if($ES['attributes']['validation_messages']->has('to_date')): ?>
                                            <script>
                                                    document.getElementById('to_date').className = 'form-control form-control-sm is-invalid';
                                            </script>
                                            <div class="invalid-feedback"><?php echo e($ES['attributes']['validation_messages']->first("to_date")); ?></div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-sm-1">
                                        <input type="submit" name="submit" id="submit" class="btn btn-primary btn-sm w-100" value="Display">
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <label for="tid" class="col-sm-1 col-form-label-sm">Remark</label>
                                    <div class="col-sm-5">
                                        <input type="text" name="remark" id="remark" class="form-control form-control-sm" value="<?php echo e($ES['attributes']['remark']); ?>">
                                        <?php if($ES['attributes']['validation_messages']->has('remark')): ?>
                                            <script>
                                                    document.getElementById('remark').className = 'form-control is-invalid';
                                            </script>
                                            <div class="invalid-feedback"><?php echo e($ES['attributes']['validation_messages']->first("remark")); ?></div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-sm-1">
                                        <input type="submit" name="submit" id="submit" class="btn btn-primary btn-sm w-100" value="Save">
                                    </div>
                                </div>

                                <hr>

                            </div>

                            <div class="col-12 colmd-12">
                                <div class="table-responsive">
                                    <table class="table table-sm table-bordered">
                                        <thead>
                                            <tr>
                                                <th style="width: 5%; background-color: yellow;">#</th>
                                                <th style="width: 10%; background-color: yellow;">Date</th>
                                                <th style="width: 10%; background-color: yellow;" class="text-end">Gross Salary</th>
                                                <th style="width: 10%; background-color: yellow;" class="text-end">Advance</th>
                                                <th style="width: 10%; background-color: yellow;" class="text-end">OT Rate (For Hour)</th>
                                                <th style="width: 10%; background-color: yellow;" class="text-end">OT Hours</th>
                                                <th style="width: 10%; background-color: yellow;" class="text-end">OT Amounts</th>
                                                <th style="width: 10%; background-color: yellow;" class="text-end">Net Salary</th>
                                                <th style="width: 10%; background-color: yellow; text-align:center !important;">Pay</th>
                                            </tr>
                                        </thead>
                                        <?php if( count($ES['attributes']['salary_detail']) >= 1 ): ?>

                                            <?php
                                                $date_serial = '19000101';
                                            ?>

                                            <tbody>
                                                <?php $__currentLoopData = $ES['attributes']['salary_detail']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td rowspan="2" style="width: 5%; vertical-align: middle; text-align:center;"><b><?php echo e($rowValue['ono']); ?> </b> </td>
                                                        <td rowspan="2" style="width: 10%; vertical-align: middle; text-align:center;"><b><?php echo e($rowValue['date']); ?> </b> </td>
                                                        <td style="width: 10%;" class="text-end"><?php echo e($rowValue['basic_salary']); ?></td>
                                                        <td style="width: 10%;" class="text-end"><?php echo e($rowValue['advance_amount']); ?></td>
                                                        <td style="width: 10%;" class="text-end">
                                                            <input type="text" name="ot_rate_<?php echo e($rowValue['date_serial']); ?>" id="ot_rate_<?php echo e($rowValue['date_serial']); ?>" class="form-control form-control-sm text-end" value="<?php echo e($rowValue['ot_rate']); ?>">
                                                        </td>
                                                        <td style="width: 10%;" class="text-end">
                                                            <input type="text" name="ot_hours_<?php echo e($rowValue['date_serial']); ?>" id="ot_hours_<?php echo e($rowValue['date_serial']); ?>" class="form-control form-control-sm text-end w-ot-hours" value="">
                                                            <?php if($ES['attributes']['validation_messages']->has('<?php echo e("ot_hours_". $date_serial); ?>')): ?>
                                                                <script>
                                                                        document.getElementById("<?php echo e('ot_hours_' . $rowValue['date_serial']); ?>").className = 'form-select form-select-sm is-invalid';
                                                                </script>
                                                                <div class="invalid-feedback"><?php echo e($ES['attributes']['validation_messages']->first("ot_hours_". $date_serial)); ?></div>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td style="width: 10%;" class="text-end">
                                                            <input type="text" name="ot_amount_<?php echo e($rowValue['date_serial']); ?>" id="ot_amount_<?php echo e($rowValue['date_serial']); ?>" class="form-control form-control-sm text-end" value="" readonly>
                                                            <?php if($ES['attributes']['validation_messages']->has('<?php echo e("ot_amount_". $date_serial); ?>')): ?>
                                                                <script>
                                                                        document.getElementById("<?php echo e('ot_amount_' . $rowValue['date_serial']); ?>").className = 'form-select form-select-sm is-invalid';
                                                                </script>
                                                                <div class="invalid-feedback"><?php echo e($ES['attributes']['validation_messages']->first("ot_amount_". $date_serial)); ?></div>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td style="width: 10%;" class="text-end">
                                                            <input type="text" name="net_salary_<?php echo e($rowValue['date_serial']); ?>" id="net_salary_<?php echo e($rowValue['date_serial']); ?>" class="form-control form-control-sm text-end" value="<?php echo e($rowValue['net_salary']); ?>" readonly>
                                                        </td>
                                                        <td rowspan="2" style="width: 10%; vertical-align: middle; text-align:center !important;" class="text-end">
                                                            <input type="checkbox" name="pay_<?php echo e($rowValue['date_serial']); ?>" id="pay_<?php echo e($rowValue['date_serial']); ?>" class="form-check-input" value="Pay">
                                                            <label class="form-check-label" for="flexCheckDefault">
                                                                Pay
                                                            </label>
                                                            <?php if($ES['attributes']['validation_messages']->has('<?php echo e("pay_". $date_serial); ?>')): ?>
                                                                <script>
                                                                        document.getElementById("<?php echo e('pay_' . $rowValue['date_serial']); ?>").className = 'form-select form-select-sm is-invalid';
                                                                </script>
                                                                <div class="invalid-feedback"><?php echo e($ES['attributes']['validation_messages']->first("pay_". $date_serial)); ?></div>
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <?php
                                                            $date_serial = $rowValue['date_serial'];
                                                        ?>

                                                        <td colspan="2" style="width: 25%;">
                                                            <select name="site_id_<?php echo e($rowValue['date_serial']); ?>" id="site_id_<?php echo e($rowValue['date_serial']); ?>" class="form-select form-select-sm w-site" >
                                                                <?php $__currentLoopData = $ES['site']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value ="<?php echo e($row->site_id); ?>"><?php echo e($row->site_name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <option value ="0" selected>Select the Site </option>
                                                            </select>
                                                            <?php if($ES['attributes']['validation_messages']->has('<?php echo e("site_id_". $date_serial); ?>')): ?>
                                                                <script>
                                                                        document.getElementById("<?php echo e('site_id_' . $rowValue['date_serial']); ?>").className = 'form-select form-select-sm is-invalid';
                                                                </script>
                                                                <div class="invalid-feedback"><?php echo e($ES['attributes']['validation_messages']->first("site_id_". $date_serial)); ?></div>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td colspan="2" style="width: 25%;">
                                                            <select name="task_id_<?php echo e($rowValue['date_serial']); ?>" id="task_id_<?php echo e($rowValue['date_serial']); ?>" class="form-select form-select-sm w-task" >
                                                                <option value ="0" selected>Select the Task </option>
                                                            </select>
                                                            <?php if($ES['attributes']['validation_messages']->has('<?php echo e("task_id". $date_serial); ?>')): ?>
                                                                <script>
                                                                        document.getElementById("<?php echo e('task_id' . $rowValue['date_serial']); ?>").className = 'form-select form-select-sm is-invalid';
                                                                </script>
                                                                <div class="invalid-feedback"><?php echo e($ES['attributes']['validation_messages']->first("task_id". $date_serial)); ?></div>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td colspan="2" style="width: 25%;">
                                                            <select name="sub_task_id_<?php echo e($rowValue['date_serial']); ?>" id="sub_task_id_<?php echo e($rowValue['date_serial']); ?>" class="form-select form-select-sm" >
                                                                <option value ="0" selected>Select the Sub Task </option>
                                                            </select>
                                                            <?php if($ES['attributes']['validation_messages']->has('<?php echo e("sub_task_id". $date_serial); ?>')): ?>
                                                                <script>
                                                                        document.getElementById("<?php echo e('sub_task_id' . $rowValue['date_serial']); ?>").className = 'form-select form-select-sm is-invalid';
                                                                </script>
                                                                <div class="invalid-feedback"><?php echo e($ES['attributes']['validation_messages']->first("sub_task_id". $date_serial)); ?></div>
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="9" style="background-color: green; height: 20px;"></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td colspan="2"><b>Total </b></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td class="text-end"><strong><?php echo number_format($ES['attributes']['pv_total'], 2); ?></strong></td>
                                                    <td></td>
                                                </tr>
                                            </tbody>

                                        <?php else: ?>
                                            <tbody>
                                                <tr>
                                                    <td style="width: 5%;">-</td>
                                                    <td style="width: 20%;">-</td>
                                                    <td style="width: 10%;" class="text-end">0.00</td>
                                                    <td style="width: 10%;" class="text-end">0.00</td>
                                                    <td style="width: 15%;" class="text-end">0</td>
                                                    <td style="width: 10%;" class="text-end">0.00</td>
                                                    <td style="width: 10%;" class="text-end">0.00</td>
                                                    <td style="width: 15%;" class="text-end">0.00</td>
                                                </tr>
                                            </tbody>
                                        <?php endif; ?>
                                    </table>
                                  </div>

                            </div>

                        </div>

                    </div>
                </div>

            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site_monitoring', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\woshitha_engineers\resources\views/SiteMM/SiteOperation/employee_salary.blade.php ENDPATH**/ ?>