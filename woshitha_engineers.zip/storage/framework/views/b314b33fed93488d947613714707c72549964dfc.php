<?php $__env->startSection('title'); ?>
    SAP Inquire
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>

    <div class="row">
        <div class="col-12">
            <form method="POST" action="<?php echo e(route('sap_inquire_process')); ?>">
                <?php echo csrf_field(); ?>

                <div class="card mt-3">

                    <div class="card-header">
                        SAP Inquire
                    </div>

                    <div class="card-body">

                        <div class="row">
                            <div class="col-sm-12">
                                <?php echo $stsil['attributes']['process_message'];  ?>
                            </div>
                        </div>

                        <div class="row no-gutters">
                            <div class="col-12 col-sm-12 col-md-12">

                                <div class="row mb-2">
                                    <label for="tid" class="col-sm-1 col-form-label-sm">Site</label>
                                    <div class="col-sm-5">
                                        <select name="site_id" id="site_id" class="form-select form-select-sm" >
                                            <?php $__currentLoopData = $stsil['site']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($stsil['attributes']['site_id'] == $row->site_id): ?>
                                                    <option value ="<?php echo e($row->site_id); ?>" selected><?php echo e($row->site_name); ?></option>
                                                <?php else: ?>
                                                    <option value ="<?php echo e($row->site_id); ?>"><?php echo e($row->site_name); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($stsil['attributes']['site_id'] == "0"): ?>
                                                <option value ="0" selected>Select the Site </option>
                                            <?php endif; ?>
                                        </select>
                                        <?php if($stsil['attributes']['validation_messages']->has('site_id')): ?>
                                            <script>
                                                    document.getElementById('site_id').className = 'form-select form-select-sm is-invalid';
                                            </script>
                                            <div class="invalid-feedback"><?php echo e($stsil['attributes']['validation_messages']->first("site_id")); ?></div>
                                        <?php endif; ?>
                                    </div>

                                    <label for="tid" class="col-sm-1 col-form-label-sm">Cost Section</label>
                                    <div class="col-sm-2">
                                        <select name="cs_id" id="cs_id" class="form-select form-select-sm" >
                                            <?php $__currentLoopData = $stsil['cost_section']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($stsil['attributes']['cs_id'] == $row->cs_id): ?>
                                                    <option value ="<?php echo e($row->cs_id); ?>" selected><?php echo e($row->cs_name); ?></option>
                                                <?php else: ?>
                                                    <option value ="<?php echo e($row->cs_id); ?>"><?php echo e($row->cs_name); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if( $stsil['attributes']['cs_id'] != "0" ): ?>
                                                <option value ="0">Select the Cost Section </option>
                                            <?php else: ?>
                                                <option value ="0" selected>Select the Cost Section </option>
                                            <?php endif; ?>
                                        </select>
                                        <?php if($stsil['attributes']['validation_messages']->has('cs_id')): ?>
                                            <script>
                                                    document.getElementById('cs_id').className = 'form-select form-select-sm is-invalid';
                                            </script>
                                            <div class="invalid-feedback"><?php echo e($stsil['attributes']['validation_messages']->first("cs_id")); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="row mb-2">
                                    <label for="tid" class="col-sm-1 col-form-label-sm">Task</label>
                                    <div class="col-sm-5">
                                        <select name="task_id" id="task_id" class="form-select form-select-sm" >
                                            <?php if( ($stsil['attributes']['task_id'] != "0") || ($stsil['attributes']['site_id'] != "0") ): ?>
                                                <?php $__currentLoopData = $stsil['site_task']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($stsil['attributes']['task_id'] == $row->task_id): ?>
                                                        <option value ="<?php echo e($row->task_id); ?>" selected><?php echo e($row->task_name); ?></option>
                                                    <?php else: ?>
                                                        <option value ="<?php echo e($row->task_id); ?>"><?php echo e($row->task_name); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            <?php if( $stsil['attributes']['task_id'] != "0" ): ?>
                                                <option value ="0">Select the Task </option>
                                            <?php else: ?>
                                                <option value ="0" selected>Select the Task </option>
                                            <?php endif; ?>
                                        </select>
                                        <?php if($stsil['attributes']['validation_messages']->has('task_id')): ?>
                                            <script>
                                                    document.getElementById('task_id').className = 'form-select form-select-sm is-invalid';
                                            </script>
                                            <div class="invalid-feedback"><?php echo e($stsil['attributes']['validation_messages']->first("task_id")); ?></div>
                                        <?php endif; ?>
                                    </div>

                                </div>

                                <div class="row mb-4">
                                    <label for="tid" class="col-sm-1 col-form-label-sm">Sub Task</label>
                                    <div class="col-sm-5">
                                        <select name="sub_task_id" id="sub_task_id" class="form-select form-select-sm" >
                                            <?php if( ($stsil['attributes']['sub_task_id'] != "0") || ($stsil['attributes']['task_id'] != "0") ): ?>
                                                <?php $__currentLoopData = $stsil['site_sub_task']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($stsil['attributes']['sub_task_id'] == $row->sub_task_id): ?>
                                                        <option value ="<?php echo e($row->sub_task_id); ?>" selected><?php echo e($row->sub_task_name); ?></option>
                                                    <?php else: ?>
                                                        <option value ="<?php echo e($row->sub_task_id); ?>"><?php echo e($row->sub_task_name); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            <?php if( $stsil['attributes']['sub_task_id'] != "0" ): ?>
                                                <option value ="0">Select the Sub Task </option>
                                            <?php else: ?>
                                                <option value ="0" selected>Select the Sub Task </option>
                                            <?php endif; ?>
                                        </select>
                                        <?php if($stsil['attributes']['validation_messages']->has('sub_task_id')): ?>
                                            <script>
                                                    document.getElementById('sub_task_id').className = 'form-select form-select-sm is-invalid';
                                            </script>
                                            <div class="invalid-feedback"><?php echo e($stsil['attributes']['validation_messages']->first("sub_task_id")); ?></div>
                                        <?php endif; ?>
                                    </div>

                                    <div class="col-sm-1">
                                        <input type="submit" name="submit" id="submit" class="btn btn-primary btn-sm w-100" value="Display">
                                    </div>
                                </div>

                            </div>
                            <hr>



                            <div class="col-12 colmd-12">
                                <div class="table-responsive">
                                    <table class="table table-sm table-bordered">
                                        <thead>
                                            <?php if( $stsil['source_name'] != 'profit' ): ?>
                                                <tr>
                                                    <th style="width: 5%;">#</th>
                                                    <th id="stsil" style="width: 55%;">
                                                        <?php echo e($stsil['source_name']); ?>

                                                    </th>
                                                    <th style="width: 10%;" class="text-end">Price</th>
                                                    <th style="width: 10%;" class="text-end">Qty</th>
                                                    <th style="width: 10%;" class="text-end">Amount</th>
                                                    <th style="width: 10%;"></th>
                                                </tr>
                                            <?php else: ?>
                                                <tr>
                                                    <th style="width: 5%;">#</th>
                                                    <th style="width: 15%;" class="text-end">Material Cost</th>
                                                    <th style="width: 15%;" class="text-end">Labour Cost</th>
                                                    <th style="width: 15%;" class="text-end">Overhead Cost</th>
                                                    <th style="width: 15%;" class="text-end">Total Cost</th>
                                                    <th style="width: 15%;" class="text-end">Profit</th>
                                                    <th style="width: 10%;"></th>
                                                </tr>
                                            <?php endif; ?>
                                        </thead>
                                        <?php if( count($stsil['stsil_detail']) >= 1 ): ?>

                                            <tbody>
                                                <?php $__currentLoopData = $stsil['stsil_detail']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowKey => $rowValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if( $stsil['source_name'] != 'profit' ): ?>
                                                        <tr>
                                                            <td style="width: 5%;"><?php echo e(($rowKey + 1)); ?></td>
                                                            <?php if( ($stsil['stsil_detail']->cost_section == 'material') ): ?>
                                                                <td style="width: 55%;"><?php echo e($rowValue->getItem()->item_name); ?></td>
                                                            <?php elseif( ($stsil['stsil_detail']->cost_section == 'labour') ): ?>
                                                                <td style="width: 55%;"><?php echo e($rowValue->getLabourCategory()->lc_name); ?></td>
                                                            <?php elseif( ($stsil['stsil_detail']->cost_section == 'overhead') ): ?>
                                                                <td style="width: 55%;"><?php echo e($rowValue->getOverheadCost()->oci_name); ?></td>
                                                            <?php endif; ?>
                                                            <td style="width: 10%;" class="text-end"><?php echo number_format($rowValue->amount, 2); ?></td>
                                                            <td style="width: 10%;" class="text-end"><?php echo e(1); ?></td>
                                                            <td style="width: 10%;" class="text-end"><?php echo number_format($rowValue->amount, 2); ?></td>
                                                            <td style="width: 10%;">
                                                                <?php if( ($stsil['stsil_detail']->cost_section == 'material') ): ?>
                                                                    <input type="button" name="btnOpen" id="btnOpen" data-sap-material-id="<?php echo e($rowValue->sap_material_id); ?>" class="btn btn-primary btn-sm w-100 <?php echo e($stsil['stsil_detail']->class_name); ?>-inquiry-open" value="Open">
                                                                <?php elseif( ($stsil['stsil_detail']->cost_section == 'labour') ): ?>
                                                                    <input type="button" name="btnOpen" id="btnOpen" data-sap-labour-id="<?php echo e($rowValue->sap_labour_id); ?>" class="btn btn-primary btn-sm w-100 <?php echo e($stsil['stsil_detail']->class_name); ?>-inquiry-open" value="Open">
                                                                <?php elseif( ($stsil['stsil_detail']->cost_section == 'overhead') ): ?>
                                                                    <input type="button" name="btnOpen" id="btnOpen" data-sap-oc-id="<?php echo e($rowValue->sap_oc_id); ?>" class="btn btn-primary btn-sm w-100 <?php echo e($stsil['stsil_detail']->class_name); ?>-inquiry-open" value="Open">
                                                                <?php endif; ?>
                                                            </td>
                                                        </tr>
                                                    <?php else: ?>
                                                        <tr>
                                                            <td style="width: 5%;"><?php echo e(($rowKey + 1)); ?></td>
                                                            <td style="width: 15%;" class="text-end"><?php echo number_format($rowValue->material_cost, 2); ?></td>
                                                            <td style="width: 15%;" class="text-end"><?php echo number_format($rowValue->labour_cost, 2); ?></td>
                                                            <td style="width: 15%;" class="text-end"><?php echo number_format($rowValue->overhead_cost, 2); ?></td>
                                                            <td style="width: 15%;" class="text-end"><?php echo number_format($rowValue->total_cost, 2); ?></td>
                                                            <td style="width: 15%;" class="text-end"><?php echo number_format($rowValue->profit_value, 2); ?></td>
                                                            <td style="width: 10%;">
                                                                <input type="button" name="btnOpen" id="btnOpen" data-sap-profit-id="<?php echo e($rowValue->sap_profit_id); ?>"  class="btn btn-primary btn-sm w-100 <?php echo e($stsil['stsil_detail']->class_name); ?>-inquiry-open" value="Open">
                                                            </td>
                                                        </tr>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>

                                        <?php else: ?>
                                            <tbody>
                                                <tr>
                                                    <td style="width: 5%;">-</td>
                                                    <td style="width: 55%;">-</td>
                                                    <td style="width: 10%;" class="text-end"><?php echo number_format(0, 2); ?></td>
                                                    <td style="width: 10%;" class="text-end"><?php echo number_format(0, 2); ?></td>
                                                    <td style="width: 10%;" class="text-end"><?php echo number_format(0, 2); ?></td>
                                                    <td style="width: 10%;"></td>
                                                </tr>
                                            </tbody>
                                        <?php endif; ?>
                                    </table>
                                  </div>

                            </div>

                        </div>

                    </div>
                </div>

            </form>
        </div>

        <div style="display: none;">
            <form id="open_sap_material" style="display: none;" method="post" target='_blank' action="<?php echo e(route('open_sap_material')); ?>">
                <?php echo csrf_field(); ?>
                <input type="text" name="open_sap_material_id" id="open_sap_material_id" values="">
            </form>
        </div>

        <div style="display: none;">
            <form id="open_sap_labour" style="display: none;" method="post" target='_blank' action="<?php echo e(route('open_sap_labour')); ?>">
                <?php echo csrf_field(); ?>
                <input type="text" name="open_sap_labour_id" id="open_sap_labour_id" values="">
            </form>
        </div>

        <div style="display: none;">
            <form id="open_sap_overhead" style="display: none;" method="post" target='_blank' action="<?php echo e(route('open_sap_overhead')); ?>">
                <?php echo csrf_field(); ?>
                <input type="text" name="open_sap_overhead_cost_id" id="open_sap_overhead_cost_id" values="">
            </form>
        </div>

        <div style="display: none;">
            <form id="open_sap_profit" style="display: none;" method="post" target='_blank' action="<?php echo e(route('open_sap_profit')); ?>">
                <?php echo csrf_field(); ?>
                <input type="text" name="open_sap_profit_id" id="open_sap_profit_id" values="">
            </form>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site_monitoring', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\woshitha_engineers\resources\views/SiteMM/InquiryList/sap_inquire.blade.php ENDPATH**/ ?>