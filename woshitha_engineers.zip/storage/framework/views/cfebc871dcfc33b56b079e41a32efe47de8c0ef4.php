<?php $__env->startSection('title'); ?>
    Site Task Sub Task Inquiry & List
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>

    <div class="row">
        <div class="col-12">
            <form method="POST" action="<?php echo e(route('site_task_subtask_inquiry_process')); ?>">
                <?php echo csrf_field(); ?>

                <div class="card mt-3">

                    <div class="card-header">
                        Site Task Sub Task Inquiry & List
                    </div>

                    <div class="card-body">

                        <div class="row">
                            <div class="col-sm-12">
                                <?php echo $stsil['attributes']['process_message'];  ?>
                            </div>
                        </div>

                        <div class="row no-gutters">
                            <div class="col-12 col-sm-12 col-md-12">

                                <div class="row mb-2">

                                    <label for="tid" class="col-sm-1 col-form-label-sm">Site</label>
                                    <div class="col-sm-5">
                                        <select name="site_id" id="site_id" class="form-select form-select-sm" >
                                            <?php $__currentLoopData = $stsil['site']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($stsil['attributes']['site_id'] == $row->site_id): ?>
                                                    <option value ="<?php echo e($row->site_id); ?>" selected><?php echo e($row->site_name); ?></option>
                                                <?php else: ?>
                                                    <option value ="<?php echo e($row->site_id); ?>"><?php echo e($row->site_name); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($stsil['attributes']['site_id'] == "0"): ?>
                                                <option value ="0" selected>Select the Site </option>
                                            <?php endif; ?>
                                        </select>
                                        <?php if($stsil['attributes']['validation_messages']->has('site_id')): ?>
                                            <script>
                                                    document.getElementById('site_id').className = 'form-select form-select-sm is-invalid';
                                            </script>
                                            <div class="invalid-feedback"><?php echo e($stsil['attributes']['validation_messages']->first("site_id")); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="row mb-2">
                                    <label for="tid" class="col-sm-1 col-form-label-sm">Task</label>
                                    <div class="col-sm-5">
                                        <select name="task_id" id="task_id" class="form-select form-select-sm" >
                                            <?php if( ($stsil['attributes']['task_id'] != "0") || ($stsil['attributes']['site_id'] != "0") ): ?>
                                                <?php $__currentLoopData = $stsil['site_task']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($stsil['attributes']['task_id'] == $row->task_id): ?>
                                                        <option value ="<?php echo e($row->task_id); ?>" selected><?php echo e($row->task_name); ?></option>
                                                    <?php else: ?>
                                                        <option value ="<?php echo e($row->task_id); ?>"><?php echo e($row->task_name); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            <?php if( $stsil['attributes']['task_id'] != "0" ): ?>
                                                <option value ="0">Select the Task </option>
                                            <?php else: ?>
                                                <option value ="0" selected>Select the Task </option>
                                            <?php endif; ?>
                                        </select>
                                        <?php if($stsil['attributes']['validation_messages']->has('task_id')): ?>
                                            <script>
                                                    document.getElementById('task_id').className = 'form-select form-select-sm is-invalid';
                                            </script>
                                            <div class="invalid-feedback"><?php echo e($stsil['attributes']['validation_messages']->first("task_id")); ?></div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-sm-1">
                                        <input type="submit" name="submit" id="submit" class="btn btn-primary btn-sm w-100" value="Display">
                                    </div>
                                </div>


                                

                            </div>
                            <hr>

                            <div class="col-12 colmd-12">
                                <div class="table-responsive">
                                    <table class="table table-sm table-bordered">
                                        <thead>
                                            <tr>
                                                <th style="width: 5%;">#</th>
                                                <th id="stsil" style="width: 65%;">
                                                    Site
                                                </th>
                                                <th style="width: 10%;">Active</th>
                                                <th style="width: 10%;">Sub Contract</th>
                                                <th style="width: 10%;"></th>
                                            </tr>
                                        </thead>
                                        <?php if( count($stsil['attributes']['stsil_detail']) >= 1 ): ?>

                                            <?php if( $stsil['attributes']['source'] == 'site' ): ?>

                                                <tbody>
                                                    <?php $__currentLoopData = $stsil['attributes']['stsil_detail']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowKey => $rowValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td style="width: 5%;"><?php echo e(($rowKey + 1)); ?></td>
                                                            <td style="width: 65%;"><?php echo e($rowValue->site_name); ?></td>
                                                            <?php if( $rowValue->active == 1 ): ?>
                                                                <td style="width: 10%;">Yes</td>
                                                            <?php else: ?>
                                                                <td style="width: 10%;">No</td>
                                                            <?php endif; ?>
                                                            <td style="width: 10%;">No</td>
                                                            <td style="width: 10%;">
                                                                <input type="button" name="btnOpen" id="btnOpen" data-site-id="<?php echo e($rowValue->site_id); ?>" class="btn btn-primary btn-sm w-100 site-inquiry-open" value="Open">
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>

                                            <?php elseif( $stsil['attributes']['source'] == 'task' ): ?>

                                                <tbody>
                                                    <?php $__currentLoopData = $stsil['attributes']['stsil_detail']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowKey => $rowValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td style="width: 5%;"><?php echo e(($rowKey + 1)); ?></td>
                                                            <td style="width: 65%;"><?php echo e($rowValue->task_name); ?></td>
                                                            <?php if( $rowValue->active == 1 ): ?>
                                                                <td style="width: 10%;">Yes</td>
                                                            <?php else: ?>
                                                                <td style="width: 10%;">No</td>
                                                            <?php endif; ?>
                                                            <?php if( $rowValue->sub_contract == 1 ): ?>
                                                                <td style="width: 10%;">Yes</td>
                                                            <?php else: ?>
                                                                <td style="width: 10%;">No</td>
                                                            <?php endif; ?>
                                                            <td style="width: 10%;">
                                                                <input type="button" name="btnOpen" id="btnOpen" data-task-id="<?php echo e($rowValue->task_id); ?>" class="btn btn-primary btn-sm w-100 task-inquiry-open" value="Open">
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>

                                            <?php elseif( $stsil['attributes']['source'] == 'sub-task' ): ?>

                                                <tbody>
                                                    <?php $__currentLoopData = $stsil['attributes']['stsil_detail']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowKey => $rowValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td style="width: 5%;"><?php echo e(($rowKey + 1)); ?></td>
                                                            <td style="width: 65%;"><?php echo e($rowValue->sub_task_name); ?></td>
                                                            <?php if( $rowValue->active == 1 ): ?>
                                                                <td style="width: 10%;">Yes</td>
                                                            <?php else: ?>
                                                                <td style="width: 10%;">No</td>
                                                            <?php endif; ?>
                                                            <?php if( $rowValue->sub_contract == 1 ): ?>
                                                                <td style="width: 10%;">Yes</td>
                                                            <?php else: ?>
                                                                <td style="width: 10%;">No</td>
                                                            <?php endif; ?>
                                                            <td style="width: 10%;">
                                                                <input type="button" name="btnOpen" id="btnOpen" data-sub-task-id="<?php echo e($rowValue->sub_task_id); ?>" class="btn btn-primary btn-sm w-100 sub-task-inquiry-open" value="Open">
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>

                                            <?php endif; ?>

                                        <?php else: ?>
                                            <tbody>
                                                <tr>
                                                    <td style="width: 5%;">-</td>
                                                    <td style="width: 65%;">-</td>
                                                    <td style="width: 10%;">-</td>
                                                    <td style="width: 10%;"></td>
                                                    <td style="width: 10%;"></td>
                                                </tr>
                                            </tbody>
                                        <?php endif; ?>
                                    </table>
                                  </div>

                            </div>

                        </div>

                    </div>
                </div>

            </form>
        </div>

        <div style="display: none;">
            <form id="open_site" style="display: none;" method="post" target='_blank' action="<?php echo e(route('open_site')); ?>">
                <?php echo csrf_field(); ?>
                <input type="text" name="open_site_id" id="open_site_id" values="">
            </form>
        </div>

        <div style="display: none;">
            <form id="open_task" style="display: none;" method="post" target='_blank' action="<?php echo e(route('open_task')); ?>">
                <?php echo csrf_field(); ?>
                <input type="text" name="open_task_id" id="open_task_id" values="">
            </form>
        </div>

        <div style="display: none;">
            <form id="open_sub_task" style="display: none;" method="post" target='_blank' action="<?php echo e(route('open_sub_task')); ?>">
                <?php echo csrf_field(); ?>
                <input type="text" name="open_site_no" id="open_site_no" values="">
                <input type="text" name="open_sub_task_id" id="open_sub_task_id" values="">
            </form>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site_monitoring', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\woshitha_engineers\resources\views/SiteMM/InquiryList/site_task_subtask.blade.php ENDPATH**/ ?>