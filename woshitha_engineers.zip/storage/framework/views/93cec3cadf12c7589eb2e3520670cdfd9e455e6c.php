<?php $__env->startSection('title'); ?>
    Employee
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>

    <div class="row">
        <div class="col-12">
            <form method="POST" action="<?php echo e(route('employee_process')); ?>">
                <?php echo csrf_field(); ?>

                <div class="card mt-3">

                    <div class="card-header">
                        Employee
                    </div>

                    <div class="card-body">

                        <div class="row">
                            <div class="col-sm-12">
                                <?php echo $Emp['attributes']['process_message'];  ?>
                            </div>
                        </div>

                        <div class="row no-gutters">
                            <div class="col-12 col-sm-8 col-md-8">

                                <div class="row mb-2">
                                    <label for="tid" class="col-sm-2 col-form-label-sm">Employee ID</label>
                                    <div class="col-sm-2">
                                        <input type="text" name="employee_id" id="employee_id" class="form-control form-control-sm"  value="<?php echo e($Emp['attributes']['employee_id']); ?>" readonly>
                                        <?php if($Emp['attributes']['validation_messages']->has('employee_id')): ?>
                                            <script>
                                                    document.getElementById('employee_id').className = 'form-control form-control-sm is-invalid';
                                            </script>
                                            <div class="invalid-feedback"><?php echo e($Emp['attributes']['validation_messages']->first("employee_id")); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="row mb-2">
                                    <label for="tid" class="col-sm-2 col-form-label-sm">Employee Code</label>
                                    <div class="col-sm-10">
                                        <input type="text" name="employee_code" id="employee_code" class="form-control form-control-sm"  value="<?php echo e($Emp['attributes']['employee_code']); ?>">
                                        <?php if($Emp['attributes']['validation_messages']->has('employee_code')): ?>
                                            <script>
                                                    document.getElementById('employee_code').className = 'form-control form-control-sm is-invalid';
                                            </script>
                                            <div class="invalid-feedback"><?php echo e($Emp['attributes']['validation_messages']->first("employee_code")); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="row mb-2">
                                    <label for="tid" class="col-sm-2 col-form-label-sm">Employee Name</label>
                                    <div class="col-sm-10">
                                        <input type="text" name="employee_name" id="employee_name" class="form-control form-control-sm"  value="<?php echo e($Emp['attributes']['employee_name']); ?>">
                                        <?php if($Emp['attributes']['validation_messages']->has('employee_name')): ?>
                                            <script>
                                                    document.getElementById('employee_name').className = 'form-control form-control-sm is-invalid';
                                            </script>
                                            <div class="invalid-feedback"><?php echo e($Emp['attributes']['validation_messages']->first("employee_name")); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="row mb-2">
                                    <label for="tid" class="col-sm-2 col-form-label-sm">Labour Category</label>
                                    <div class="col-sm-4">
                                        <select name="lc_id" id="lc_id" class="form-select form-select-sm" >
                                            <?php $__currentLoopData = $Emp['labour_category']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($Emp['attributes']['lc_id'] == $row->lc_id): ?>
                                                    <option value ="<?php echo e($row->lc_id); ?>" selected><?php echo e($row->lc_name . '  --> ' . number_format($row->price, 2)); ?></option>
                                                <?php else: ?>
                                                    <option value ="<?php echo e($row->lc_id); ?>"><?php echo e($row->lc_name . '  --> ' . number_format($row->price, 2)); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($Emp['attributes']['lc_id'] == "0"): ?>
                                                <option value ="0" selected>Select the Labour Category </option>
                                            <?php endif; ?>
                                        </select>
                                        <?php if($Emp['attributes']['validation_messages']->has('lc_id')): ?>
                                            <script>
                                                    document.getElementById('lc_id').className = 'form-select form-select-sm is-invalid';
                                            </script>
                                            <div class="invalid-feedback"><?php echo e($Emp['attributes']['validation_messages']->first("lc_id")); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="row mb-4">
                                    <label for="tid" class="col-sm-2 col-form-label-sm">Active</label>
                                    <div class="col-sm-2">
                                        <select name="active" id="active" class="form-select form-select-sm" >
                                            <?php if( $Emp['attributes']['active'] ): ?>
                                                <option value ="1" selected>Yes</option>
                                                <option value ="0">No</option>
                                            <?php else: ?>
                                                <option value ="1">Yes</option>
                                                <option value ="0" selected>No</option>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                </div>

                                <div  class="row mb-2">
                                    <div class="col-2">
                                        <input type="submit" name="submit" id="submit" style="width: 100%;" class="btn btn-primary btn-sm" value="Save">
                                    </div>
                                </div>

                            </div>

                            <div class="col-12 col-sm-4 col-md-4">
                            </div>

                        </div>

                    </div>
                </div>

            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site_monitoring', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\woshitha_engineers\resources\views/SiteMM/Master/employee.blade.php ENDPATH**/ ?>