

<?php $__env->startSection('title'); ?>
    Manufacture Location
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

    <div id="tbldiv" style="width: 98%;  margin-right: 1%; margin-left: 1%; margin-top: 1%;">
    <form method="POST" action="<?php echo e(route('manufacture_location_process')); ?>">

        <?php echo csrf_field(); ?>

        <div class="col-sm-12">
            
            <div class="card">

                <div class="card-header">
                    Manufacture Location
                </div>

                <div class="card-body">

                    <div class="col-sm-11">
                        <?php echo $ML['attributes']['process_message'];  ?>
                    </div>

                    <div class="mb-2 row">
                        <label for="tid" class="col-sm-2 col-form-label-sm">Manufacture Location ID</label>
                        <div class="col-sm-1">
                            <input type="text" name="manufacture_location_id" id="manufacture_location_id" class="form-control form-control-sm"  value="<?php echo e($ML['attributes']['manufacture_location_id']); ?>" readonly>
                            <?php if($ML['attributes']['validation_messages']->has('manufacture_location_id')): ?>
                            <script>
                                    document.getElementById('manufacture_location_id').className = 'form-control form-control-sm is-invalid';
                            </script>
                            <div class="invalid-feedback"><?php echo e($ML['attributes']['validation_messages']->first("manufacture_location_id")); ?></div>
                        <?php endif; ?>
                        </div>
                    </div>

                    <div class="mb-2 row">
                        <label for="tid" class="col-sm-2 col-form-label-sm">Manufacture Location Name</label>
                        <div class="col-sm-10">
                            <input type="text" name="manufacture_location_name" id="manufacture_location_name" class="form-control form-control-sm"  value="<?php echo e($ML['attributes']['manufacture_location_name']); ?>">
                            <?php if($ML['attributes']['validation_messages']->has('manufacture_location_name')): ?>
                                <script>
                                        document.getElementById('manufacture_location_name').className = 'form-control form-control-sm is-invalid';
                                </script>
                                <div class="invalid-feedback"><?php echo e($ML['attributes']['validation_messages']->first("manufacture_location_name")); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="mb-5 row">
                        <label for="tid" class="col-sm-2 col-form-label-sm">Active</label>
                        <div class="col-sm-2">
                            <select name="active" id="active" class="form-select form-select-sm" >
                                <?php if( $ML['attributes']['active'] ): ?>
                                    <option value ="1" selected>Yes</option>
                                    <option value ="0">No</option>
                                <?php else: ?>
                                    <option value ="1">Yes</option>
                                    <option value ="0" selected>No</option>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div  class="mb-2 row">

                        <div class="col-2">
                              <input type="submit" name="submit" id="submit" style="width: 100%;" class="btn btn-primary btn-sm" value="Save">
                        </div>
                       
                    </div>

                    
                </div>
            </div>

        </div>

    </form>
    </div> 

    <script>

        $('#supplier').keypress(function (e) {
            if (e.which == 13) {
                e.preventDefault();
            }
        });

    </script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.inventory', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ceylon_finance\resources\views/inventory/primary/manufacture_location.blade.php ENDPATH**/ ?>