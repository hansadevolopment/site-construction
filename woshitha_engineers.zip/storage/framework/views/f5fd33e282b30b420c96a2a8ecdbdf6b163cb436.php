

<?php $__env->startSection('title'); ?>
    Inventory Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.inventory', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SeelanFinance\resources\views/inventory/inventory_dashboard.blade.php ENDPATH**/ ?>