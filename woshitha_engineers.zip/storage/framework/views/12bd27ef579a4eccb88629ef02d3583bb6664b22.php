<?php $__env->startSection('title'); ?>
    Item Issue Note
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>

    <div class="row">
        <div class="col-12">
            <form method="POST" action="<?php echo e(route('item_issue_note_process')); ?>">
                <?php echo csrf_field(); ?>

                <div class="card mt-3">

                    <div class="card-header">
                        Item Issue Note
                    </div>

                    <div class="card-body">

                        <div class="row">
                            <div class="col-sm-12">
                                <?php echo $IIN['attributes']['process_message'];  ?>
                            </div>
                        </div>

                        <div class="row no-gutters">
                            <div class="col-12 col-sm-12 col-md-12">

                                <div class="row mb-2">

                                    <label for="tid" class="col-sm-1 col-form-label-sm">Site</label>
                                    <div class="col-sm-5">
                                        <select name="site_id" id="site_id" class="form-select form-select-sm" >
                                            <?php $__currentLoopData = $IIN['site']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($IIN['attributes']['site_id'] == $row->site_id): ?>
                                                    <option value ="<?php echo e($row->site_id); ?>" selected><?php echo e($row->site_name); ?></option>
                                                <?php else: ?>
                                                    <option value ="<?php echo e($row->site_id); ?>"><?php echo e($row->site_name); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($IIN['attributes']['site_id'] == "0"): ?>
                                                <option value ="0" selected>Select the Site </option>
                                            <?php endif; ?>
                                        </select>
                                        <?php if($IIN['attributes']['validation_messages']->has('site_id')): ?>
                                            <script>
                                                    document.getElementById('site_id').className = 'form-select form-select-sm is-invalid';
                                            </script>
                                            <div class="invalid-feedback"><?php echo e($IIN['attributes']['validation_messages']->first("site_id")); ?></div>
                                        <?php endif; ?>
                                    </div>

                                    <div class="col-sm-3">
                                    </div>

                                    <label for="tid" class="col-sm-1 col-form-label-sm">IIN No</label>
                                    <div class="col-sm-2">
                                        <input type="text" name="iin_id" id="iin_id" class="form-control form-control-sm" value="<?php echo e($IIN['attributes']['iin_id']); ?>">
                                    </div>

                                </div>

                                <div class="row mb-2">
                                    <label for="tid" class="col-sm-1 col-form-label-sm">Task</label>
                                    <div class="col-sm-5">
                                        <select name="task_id" id="task_id" class="form-select form-select-sm" >
                                            <?php if( ($IIN['attributes']['task_id'] != "0") || ($IIN['attributes']['site_id'] != "0") ): ?>
                                                <?php $__currentLoopData = $IIN['site_task']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($IIN['attributes']['task_id'] == $row->task_id): ?>
                                                        <option value ="<?php echo e($row->task_id); ?>" selected><?php echo e($row->task_name); ?></option>
                                                    <?php else: ?>
                                                        <option value ="<?php echo e($row->task_id); ?>"><?php echo e($row->task_name); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            <?php if( $IIN['attributes']['task_id'] != "0" ): ?>
                                                <option value ="0">Select the Task </option>
                                            <?php else: ?>
                                                <option value ="0" selected>Select the Task </option>
                                            <?php endif; ?>
                                        </select>
                                        <?php if($IIN['attributes']['validation_messages']->has('task_id')): ?>
                                            <script>
                                                    document.getElementById('task_id').className = 'form-select form-select-sm is-invalid';
                                            </script>
                                            <div class="invalid-feedback"><?php echo e($IIN['attributes']['validation_messages']->first("task_id")); ?></div>
                                        <?php endif; ?>
                                    </div>
                                    <label for="tid" class="col-sm-1 col-form-label-sm">Task Unit</label>
                                    <div class="col-sm-2">
                                        <input type="text" name="task_unit" id="task_unit" class="form-control form-control-sm" value="" readonly>
                                    </div>
                                    <label for="tid" class="col-sm-1 col-form-label-sm">IIN Date</label>
                                    <div class="col-sm-2">
                                        <input type="date" name="iin_date" id="iin_date" class="form-control form-control-sm" value="<?php echo e($IIN['attributes']['iin_date']); ?>">
                                    </div>
                                </div>

                                <div class="row mb-2">
                                    <label for="tid" class="col-sm-1 col-form-label-sm">Sub Task</label>
                                    <div class="col-sm-5">
                                        <select name="sub_task_id" id="sub_task_id" class="form-select form-select-sm" >
                                            <?php if( ($IIN['attributes']['sub_task_id'] != "0") || ($IIN['attributes']['task_id'] != "0") ): ?>
                                                <?php $__currentLoopData = $IIN['site_sub_task']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($IIN['attributes']['sub_task_id'] == $row->sub_task_id): ?>
                                                        <option value ="<?php echo e($row->sub_task_id); ?>" selected><?php echo e($row->sub_task_name); ?></option>
                                                    <?php else: ?>
                                                        <option value ="<?php echo e($row->sub_task_id); ?>"><?php echo e($row->sub_task_name); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            <?php if( $IIN['attributes']['sub_task_id'] != "0" ): ?>
                                                <option value ="0">Select the Sub Task </option>
                                            <?php else: ?>
                                                <option value ="0" selected>Select the Sub Task </option>
                                            <?php endif; ?>
                                        </select>
                                        <?php if($IIN['attributes']['validation_messages']->has('sub_task_id')): ?>
                                            <script>
                                                    document.getElementById('sub_task_id').className = 'form-select form-select-sm is-invalid';
                                            </script>
                                            <div class="invalid-feedback"><?php echo e($IIN['attributes']['validation_messages']->first("sub_task_id")); ?></div>
                                        <?php endif; ?>
                                    </div>

                                    <div class="col-sm-1">
                                        <input type="submit" name="submit" id="submit" class="btn btn-primary btn-sm w-100" value="Display">
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <label for="tid" class="col-sm-1 col-form-label-sm">Remark</label>
                                    <div class="col-sm-11">
                                        <textarea  name="remark" id="remark" class="form-control" rows="2" style="resize:none"><?php echo e($IIN['attributes']['remark']); ?></textarea>
                                        <?php if($IIN['attributes']['validation_messages']->has('remark')): ?>
                                            <script>
                                                    document.getElementById('remark').className = 'form-control is-invalid';
                                            </script>
                                            <div class="invalid-feedback"><?php echo e($IIN['attributes']['validation_messages']->first("remark")); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="row mb-2">
                                    <div class="col-sm-1">
                                        <input type="submit" name="submit" id="submit" class="btn btn-primary btn-sm w-100" value="Save">
                                    </div>
                                    <div class="col-sm-1">
                                        <input type="submit" name="submit" id="submit" class="btn btn-primary btn-sm w-100" value="Confirm">
                                    </div>
                                    <div class="col-sm-1">
                                        <input type="submit" name="submit" id="submit" class="btn btn-primary btn-sm w-100" value="Reset">
                                    </div>
                                    <div class="col-sm-1">
                                        <input type="submit" name="submit" id="submit" class="btn btn-primary btn-sm w-100" value="Cancel">
                                    </div>
                                    <div class="col-sm-1">
                                        <input type="submit" name="submit" id="submit" class="btn btn-primary btn-sm w-100" value="Print">
                                    </div>
                                </div>
                                <hr>

                                <div class="row mb-3">

                                    <label for="tid" class="col-sm-1 col-form-label-sm">Item</label>
                                    <div class="col-sm-5">
                                        <select name="item_id" id="item_id" class="form-select form-select-sm">
                                            <?php $__currentLoopData = $IIN['item']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value ="<?php echo e($row->item_id); ?>"><?php echo e($row->item_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <option value ="0" selected>Select the Item</option>
                                        </select>
                                        <?php if($IIN['attributes']['validation_messages']->has('item_id')): ?>
                                            <script>
                                                    document.getElementById('item_id').className = 'form-select form-select-sm is-invalid';
                                            </script>
                                            <div class="invalid-feedback"><?php echo e($IIN['attributes']['validation_messages']->first("item_id")); ?></div>
                                        <?php endif; ?>
                                    </div>

                                    <div class="col-sm-1">
                                        <input type="text" name="unit" id="unit" class="form-control form-control-sm" value="" placeholder="Unit" readonly>
                                    </div>

                                    <div class="col-sm-2">
                                        <input type="text" name="price" id="price" class="form-control form-control-sm text-end" value="" placeholder="Price" readonly>
                                    </div>

                                    <div class="col-sm-2">
                                        <input type="text" name="quantity" id="quantity" class="form-control form-control-sm text-end" value="" placeholder="Quantity">
                                        <?php if($IIN['attributes']['validation_messages']->has('quantity')): ?>
                                            <script>
                                                    document.getElementById('quantity').className = 'form-control form-control-sm is-invalid';
                                            </script>
                                            <div class="invalid-feedback"><?php echo e($IIN['attributes']['validation_messages']->first("quantity")); ?></div>
                                        <?php endif; ?>
                                    </div>

                                    <div class="col-sm-1">
                                        <input type="submit" name="submit" id="submit" class="btn btn-success btn-sm w-100" value="Add">
                                    </div>
                                </div>


                                <hr>

                            </div>

                            <div class="col-12 colmd-12">
                                <div class="table-responsive">
                                    <table class="table table-sm table-bordered">
                                        <thead>
                                            <tr>
                                                <th style="width: 5%;">#</th>
                                                <th style="width: 55%;">Item</th>
                                                <th style="width: 10%;">Unit</th>
                                                <th style="width: 10%;" class="text-end">Price</th>
                                                <th style="width: 10%;" class="text-end">Qty</th>
                                                <th style="width: 10%;" class="text-end">(Rs.) Amount</th>
                                            </tr>
                                        </thead>
                                        <?php if( count($IIN['attributes']['iin_detail']) >= 1 ): ?>

                                            <tbody>
                                                <?php $__currentLoopData = $IIN['attributes']['iin_detail']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowKey => $rowValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td style="width: 5%;"><?php echo e($rowValue->ono); ?></td>
                                                        <td style="width: 45%;"><?php echo e($rowValue->item_name); ?></td>
                                                        <td style="width: 10%;"><?php echo e($rowValue->unit_name); ?></td>
                                                        <td style="width: 10%;" class="text-end"><?php echo number_format($rowValue->price, 2); ?></td>
                                                        <td style="width: 10%;" class="text-end"><?php echo e($rowValue->quantity); ?></td>
                                                        <td style="width: 10%;" class="text-end"><?php echo number_format($rowValue->amount, 2); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td colspan="5">Total</td>
                                                    <td class="text-end"><strong><?php echo number_format($IIN['attributes']['iin_total'], 2); ?></strong></td>
                                                    <td></td>
                                                </tr>
                                            </tbody>

                                        <?php else: ?>
                                            <tbody>
                                                <tr>
                                                    <td style="width: 5%;">-</td>
                                                    <td style="width: 45%;">-</td>
                                                    <td style="width: 10%;">-</td>
                                                    <td style="width: 10%;" class="text-end">0.00</td>
                                                    <td style="width: 10%;" class="text-end">0</td>
                                                    <td style="width: 10%;" class="text-end">0.00</td>
                                                </tr>
                                            </tbody>
                                        <?php endif; ?>
                                    </table>
                                  </div>

                            </div>

                        </div>

                    </div>
                </div>

            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site_monitoring', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\woshitha_engineers\resources\views/SiteMM/SiteOperation/item_issue_note.blade.php ENDPATH**/ ?>