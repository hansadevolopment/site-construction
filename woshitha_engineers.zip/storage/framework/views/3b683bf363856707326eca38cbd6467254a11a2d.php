<?php $__env->startSection('title'); ?>
    Site Task
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>

    <div class="row">
        <div class="col-12">
            <form method="POST" action="<?php echo e(route('site_task_process')); ?>">
                <?php echo csrf_field(); ?>

                <div class="card mt-3">

                    <div class="card-header">
                        Site Task
                    </div>

                    <div class="card-body">

                        <div class="row">
                            <div class="col-sm-12">
                                <?php echo $Site['attributes']['process_message'];  ?>
                            </div>
                        </div>

                        <div class="row no-gutters">
                            <div class="col-12 col-sm-6 col-md-6">

                                <div class="row mb-2">
                                    <label for="tid" class="col-sm-2 col-form-label-sm">Task ID</label>
                                    <div class="col-sm-2">
                                        <input type="text" name="task_id" id="task_id" class="form-control form-control-sm"  value="<?php echo e($Site['attributes']['task_id']); ?>" readonly>
                                        <?php if($Site['attributes']['validation_messages']->has('task_id')): ?>
                                            <script>
                                                    document.getElementById('task_id').className = 'form-control form-control-sm is-invalid';
                                            </script>
                                            <div class="invalid-feedback"><?php echo e($Site['attributes']['validation_messages']->first("task_id")); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="row mb-2">
                                    <label for="tid" class="col-sm-2 col-form-label-sm">Name</label>
                                    <div class="col-sm-10">
                                        <input type="text" name="task_name" id="task_name" class="form-control form-control-sm"  value="<?php echo e($Site['attributes']['task_name']); ?>">
                                        <?php if($Site['attributes']['validation_messages']->has('Task Name')): ?>
                                            <script>
                                                    document.getElementById('task_name').className = 'form-control form-control-sm is-invalid';
                                            </script>
                                            <div class="invalid-feedback"><?php echo e($Site['attributes']['validation_messages']->first("Task Name")); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="row mb-2">
                                    <label for="tid" class="col-sm-2 col-form-label-sm">Site</label>
                                    <div class="col-sm-10">
                                        <select name="site_id" id="site_id" class="form-select form-select-sm" >
                                            <?php $__currentLoopData = $Site['site']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($Site['attributes']['site_id'] == $row->site_id): ?>
                                                    <option value ="<?php echo e($row->site_id); ?>" selected><?php echo e($row->site_name); ?></option>
                                                <?php else: ?>
                                                    <option value ="<?php echo e($row->site_id); ?>"><?php echo e($row->site_name); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($Site['attributes']['site_id'] == "0"): ?>
                                                <option value ="0" selected>Select the Site </option>
                                            <?php endif; ?>
                                        </select>
                                        <?php if($Site['attributes']['validation_messages']->has('Task Name')): ?>
                                            <script>
                                                    document.getElementById('task_name').className = 'form-control form-control-sm is-invalid';
                                            </script>
                                            <div class="invalid-feedback"><?php echo e($Site['attributes']['validation_messages']->first("Task Name")); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="row mb-2">
                                    <label for="tid" class="col-sm-2 col-form-label-sm">Start Date</label>
                                    <div class="col-sm-4">
                                        <input type="date" name="start_date" id="start_date" class="form-control form-control-sm"  value="<?php echo e($Site['attributes']['start_date']); ?>">
                                        <?php if($Site['attributes']['validation_messages']->has('Start Date')): ?>
                                            <script>
                                                    document.getElementById('start_date').className = 'form-control form-control-sm is-invalid';
                                            </script>
                                            <div class="invalid-feedback"><?php echo e($Site['attributes']['validation_messages']->first("Start Date")); ?></div>
                                        <?php endif; ?>
                                    </div>
                                    <label for="tid" class="col-sm-2 col-form-label-sm">End Date</label>
                                    <div class="col-sm-4">
                                        <input type="date" name="end_date" id="end_date" class="form-control form-control-sm"  value="<?php echo e($Site['attributes']['end_date']); ?>">
                                        <?php if($Site['attributes']['validation_messages']->has('Start Date')): ?>
                                            <script>
                                                    document.getElementById('end_date').className = 'form-control form-control-sm is-invalid';
                                            </script>
                                            <div class="invalid-feedback"><?php echo e($Site['attributes']['validation_messages']->first("Start Date")); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="row mb-2">
                                    <label for="tid" class="col-sm-2 col-form-label-sm">Active</label>
                                    <div class="col-sm-4">
                                        <select name="active" id="active" class="form-select form-select-sm" >
                                            <?php if( $Site['attributes']['active'] ): ?>
                                                <option value ="1" selected>Yes</option>
                                                <option value ="0">No</option>
                                            <?php else: ?>
                                                <option value ="1">Yes</option>
                                                <option value ="0" selected>No</option>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                    <label for="tid" class="col-sm-2 col-form-label-sm">Sub Contract</label>
                                    <div class="col-sm-4">
                                        <select name="sub_contract" id="sub_contract" class="form-select form-select-sm" >
                                            <?php if( $Site['attributes']['sub_contract'] ): ?>
                                                <option value ="1" selected>Yes</option>
                                                <option value ="0">No</option>
                                            <?php else: ?>
                                                <option value ="1">Yes</option>
                                                <option value ="0" selected>No</option>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <label for="tid" class="col-sm-2 col-form-label-sm">Remark</label>
                                    <div class="col-sm-10">
                                        <textarea  name="remark" id="remark" class="form-control" rows="2" style="resize:none"><?php echo e($Site['attributes']['remark']); ?></textarea>
                                        <?php if($Site['attributes']['validation_messages']->has('remark')): ?>
                                            <script>
                                                    document.getElementById('remark').className = 'form-control is-invalid';
                                            </script>
                                            <div class="invalid-feedback"><?php echo e($Site['attributes']['validation_messages']->first("remark")); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div  class="row mb-2">
                                    <div class="col-2">
                                        <input type="submit" name="submit" id="submit" style="width: 100%;" class="btn btn-primary btn-sm" value="Save">
                                    </div>
                                </div>

                            </div>

                            <div class="col-12 col-sm-6 col-md-6">
                            </div>

                        </div>

                    </div>
                </div>

            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site_monitoring', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\woshitha_engineers\resources\views/SiteMM/SiteForcast/site_task.blade.php ENDPATH**/ ?>