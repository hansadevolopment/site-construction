<?php $__env->startSection('title'); ?>
    Site
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site_monitoring', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\woshitha_engineers\resources\views/SiteMM/site_dashboard.blade.php ENDPATH**/ ?>