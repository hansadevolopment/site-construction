

<?php $__env->startSection('title'); ?>
    Sales Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sales', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SeelanFinance\resources\views/sales/sales_dashboard.blade.php ENDPATH**/ ?>