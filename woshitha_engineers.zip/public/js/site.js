
$(document).ready(function() {

    $("#site_id").change(function() {

        var site_id = $('#site_id').val();
        var task_id = $('#task_id').val();
        var sub_task_id = $('#sub_task_id').val();

        $.ajax({
            url : "/get_site_wise_task",
            method : 'GET',
            data : {
                "_token": "{{ csrf_token() }}",
                site_id: site_id
            },
            error: function(xhr, status, error) {
                var errorMessage = xhr.status + ': ' + xhr.statusText + ': ' + xhr.responseText
                alert('Error - ' + errorMessage);
            },
            success:function(response){

                $('#task_id').html(response);
            }
        });

        getSiteWiseTotalCost(site_id, task_id, sub_task_id);

    });

    $("#task_id").change(function() {

        var site_id = $('#site_id').val();
        var task_id = $('#task_id').val();
        var sub_task_id = $('#sub_task_id').val();

        $.ajax({
            url : "/get_site_wise_sub_task",
            method : 'GET',
            data : {
                "_token": "{{ csrf_token() }}",
                site_id : site_id,
                task_id : task_id
            },
            error: function(xhr, status, error) {
                var errorMessage = xhr.status + ': ' + xhr.statusText + ': ' + xhr.responseText
                alert('Error - ' + errorMessage);
            },
            success:function(response){

                $('#sub_task_id').html(response);
            }
        });

        getSiteWiseTotalCost(site_id, task_id, sub_task_id);

    });

    $("#sub_task_id").change(function() {

        var site_id = $('#site_id').val();
        var task_id = $('#task_id').val();
        var sub_task_id = $('#sub_task_id').val();

        getSiteWiseTotalCost(site_id, task_id, sub_task_id);

    });

    $("#item_id").change(function() {

        var item_id = $(this).val();

        $.ajax({
            url : "/get_item_for_sap_material",
            method : 'GET',
            data : {
                "_token": "{{ csrf_token() }}",
                item_id: item_id
            },
            error: function(xhr, status, error) {
                var errorMessage = xhr.status + ': ' + xhr.statusText + ': ' + xhr.responseText
                alert('Error - ' + errorMessage);
            },
            success:function(response){

                $("#unit").val(response['unit']);
                $("#price").val(response['price']);
                $("#quanity").focus();
            }
        });
    });

    $("#lc_id").change(function() {

        var lc_id = $(this).val();

        $.ajax({
            url : "/get_labour_category_for_sap_labour",
            method : 'GET',
            data : {
                "_token": "{{ csrf_token() }}",
                lc_id: lc_id
            },
            error: function(xhr, status, error) {
                var errorMessage = xhr.status + ': ' + xhr.statusText + ': ' + xhr.responseText
                alert('Error - ' + errorMessage);
            },
            success:function(response){

                $("#price").val(response['price']);
                $("#quanity").focus();
            }
        });
    });

    $('.w-site').change(function(event){

        var target_id = event.target.id;
        var explode_result =target_id.split('_');
        var date_serial = explode_result[2];

        var site_id = $('#'+event.target.id).val();

        $.ajax({
            url : "/get_site_wise_task",
            method : 'GET',
            data : {
                "_token": "{{ csrf_token() }}",
                site_id: site_id
            },
            error: function(xhr, status, error) {
                var errorMessage = xhr.status + ': ' + xhr.statusText + ': ' + xhr.responseText
                alert('Error - ' + errorMessage);
            },
            success:function(response){

                $('#task_id_'+date_serial).html(response);
            }
        });
    });

    $('.w-task').change(function(event){

        var target_id = event.target.id;
        var explode_result = target_id.split('_');
        var date_serial = explode_result[2];

        var site_id = $('#site_id_'+date_serial).val();
        var task_id = $('#'+event.target.id).val();


        $.ajax({
            url : "/get_site_wise_sub_task",
            method : 'GET',
            data : {
                "_token": "{{ csrf_token() }}",
                site_id : site_id,
                task_id : task_id
            },
            error: function(xhr, status, error) {
                var errorMessage = xhr.status + ': ' + xhr.statusText + ': ' + xhr.responseText
                alert('Error - ' + errorMessage);
            },
            success:function(response){

                $('#sub_task_id_'+date_serial).html(response);
            }
        });
    });

    $('.w-ot-hours').focusout(function(event){

        var target_id = event.target.id;
        var explode_result = target_id.split('_');
        var date_serial = explode_result[2];

        var ot_rate =  $('#ot_rate_'+date_serial).val();
        var ot_hours = parseFloat($(this).val());
        var ot_amount = ot_rate * ot_hours;
        var net_salary = $('#net_salary_'+date_serial).val();
        var net_salary = parseFloat(net_salary);
        $('#net_salary_'+date_serial).val((net_salary + ot_amount));

        $('#ot_amount_'+date_serial).val(currencyNumberFormat(ot_amount));

    });

    $('.site-inquiry-open').click(function(){

        let site_id = $(this).data("site-id");
        $("#open_site_id").val(site_id);
        $("#open_site").submit();
    });

    $('.task-inquiry-open').click(function(){

        let task_id = $(this).data("task-id");
        $("#open_task_id").val(task_id);
        $("#open_task").submit();
    });

    $('.sub-task-inquiry-open').click(function(){

        let sub_task_id = $(this).data("sub-task-id");
        let site_id = $("#site_id").val();

        $("#open_site_no").val(site_id);
        $("#open_sub_task_id").val(sub_task_id);
        $("#open_sub_task").submit();
    });

    $('.sap-material-inquiry-open').click(function(){

        let sap_material_id = $(this).data("sap-material-id");

        $("#open_sap_material_id").val(sap_material_id);
        $("#open_sap_material").submit();
    });

    $('.sap-labour-inquiry-open').click(function(){

        let sap_labour_id = $(this).data("sap-labour-id");

        $("#open_sap_labour_id").val(sap_labour_id);
        $("#open_sap_labour").submit();
    });

    $('.sap-overhead-inquiry-open').click(function(){

        let overhead_cost_item_id = $(this).data("sap-oc-id");

        $("#open_sap_overhead_cost_id").val(overhead_cost_item_id);
        $("#open_sap_overhead").submit();
    });

    $('.sap-profit-inquiry-open').click(function(){

        let profit_id = $(this).data("sap-profit-id");

        $("#open_sap_profit_id").val(profit_id);
        $("#open_sap_profit").submit();
    });

    $('.item-master-open').click(function(){

        let item_id = $(this).data("item-id");

        $("#item_id").val(item_id);
        $("#open_item").submit();
    });

    $('.employee-inquiry-open').click(function(){

        let employee_id = $(this).data("employee-id");

        $("#employee_id").val(employee_id);
        $("#open_employee").submit();
    });

    $('.lc-inquiry-open').click(function(){

        let lc_id = $(this).data("lc-id");

        $("#lc_id").val(lc_id);
        $("#open_labour_category").submit();
    });

    $('.oci-inquiry-open').click(function(){

        let oci_id = $(this).data("oci-id");

        $("#oci_id").val(oci_id);
        $("#open_overhead").submit();
    });

    $('.unit-inquiry-open').click(function(){

        let unit_id = $(this).data("unit-id");

        $("#unit_id").val(unit_id);
        $("#open_unit").submit();
    });

});


function getSiteWiseTotalCost(site_id, task_id, sub_task_id){

    $.ajax({
        url : "/sap_profit_total",
        method : 'GET',
        data : {
            "_token": "{{ csrf_token() }}",
            site_id: site_id,
            task_id: task_id,
            sub_task_id:sub_task_id
        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText + ': ' + xhr.responseText
            alert('Error - ' + errorMessage);
        },
        success:function(response){

            //console.log(response);

            $("#material_cost").val(response['material_cost']);
            $("#labour_cost").val(response['labour_cost']);
            $("#overhead_cost").val(response['overhead_cost']);
            $('#total_cost').val(response['total_cost']);
        }
    });

}

function currencyNumberFormat(number){

    //var number_format = new Intl.NumberFormat().format(number);

    let USDollar = new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'INR',
    });

    return USDollar.format(number);

}

