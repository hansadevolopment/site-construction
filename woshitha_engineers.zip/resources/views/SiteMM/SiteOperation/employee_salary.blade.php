@extends('layouts.site_monitoring')
@section('title')
    Employee Salary
@endsection
@section('body')

    <div class="row">
        <div class="col-12">
            <form method="POST" action="{{route('employee_salary_process')}}">
                @csrf

                <div class="card mt-3">

                    <div class="card-header">
                        Employee Salary
                    </div>

                    <div class="card-body">

                        <div class="row">
                            <div class="col-sm-12">
                                <?php echo $ES['attributes']['process_message'];  ?>
                            </div>
                        </div>

                        <div class="row no-gutters">
                            <div class="col-12 col-sm-12 col-md-12">

                                <div class="row mb-2">

                                    <div class="col-sm-9">
                                    </div>

                                    <label for="tid" class="col-sm-1 col-form-label-sm">PV No</label>
                                    <div class="col-sm-2">
                                        <input type="text" name="pv_id" id="pv_id" class="form-control form-control-sm" value="{{$ES['attributes']['pv_id']}}" readonly>
                                    </div>

                                </div>


                                <div class="row mb-2">

                                    <label for="tid" class="col-sm-1 col-form-label-sm">Employee</label>
                                    <div class="col-sm-5">
                                        <select name="employee_id" id="employee_id" class="form-select form-select-sm" >
                                            @foreach($ES['employee'] as $row)
                                                @if($ES['attributes']['employee_id'] == $row->employee_id)
                                                    <option value ="{{$row->employee_id}}" selected>{{$row->employee_name}}</option>
                                                @else
                                                    <option value ="{{$row->employee_id}}">{{$row->employee_name}}</option>
                                                @endif
                                            @endforeach
                                            @if($ES['attributes']['employee_id'] == "0")
                                                <option value ="0" selected>Select the Employee </option>
                                            @endif
                                        </select>
                                        @if($ES['attributes']['validation_messages']->has('employee_id'))
                                            <script>
                                                    document.getElementById('employee_id').className = 'form-select form-select-sm is-invalid';
                                            </script>
                                            <div class="invalid-feedback">{{ $ES['attributes']['validation_messages']->first("employee_id") }}</div>
                                        @endif
                                    </div>

                                    <div class="col-sm-3">
                                    </div>

                                    <label for="tid" class="col-sm-1 col-form-label-sm">PV Date</label>
                                    <div class="col-sm-2">
                                        <input type="date" name="pv_date" id="pv_date" class="form-control form-control-sm" value="{{$ES['attributes']['pv_date']}}">
                                    </div>

                                </div>

                                <div class="row mb-2">
                                    <label for="tid" class="col-sm-1 col-form-label-sm">From Date</label>
                                    <div class="col-sm-2">
                                        <input type="date" name="from_date" id="from_date" class="form-control form-control-sm" value="{{$ES['attributes']['from_date']}}">
                                        @if($ES['attributes']['validation_messages']->has('from_date'))
                                            <script>
                                                    document.getElementById('from_date').className = 'form-control form-control-sm is-invalid';
                                            </script>
                                            <div class="invalid-feedback">{{ $ES['attributes']['validation_messages']->first("from_date") }}</div>
                                        @endif
                                    </div>
                                    <label for="tid" class="col-sm-1 col-form-label-sm">To Date</label>
                                    <div class="col-sm-2">
                                        <input type="date" name="to_date" id="to_date" class="form-control form-control-sm" value="{{$ES['attributes']['to_date']}}">
                                        @if($ES['attributes']['validation_messages']->has('to_date'))
                                            <script>
                                                    document.getElementById('to_date').className = 'form-control form-control-sm is-invalid';
                                            </script>
                                            <div class="invalid-feedback">{{ $ES['attributes']['validation_messages']->first("to_date") }}</div>
                                        @endif
                                    </div>
                                    <div class="col-sm-1">
                                        <input type="submit" name="submit" id="submit" class="btn btn-primary btn-sm w-100" value="Display">
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <label for="tid" class="col-sm-1 col-form-label-sm">Remark</label>
                                    <div class="col-sm-5">
                                        <input type="text" name="remark" id="remark" class="form-control form-control-sm" value="{{$ES['attributes']['remark']}}">
                                        @if($ES['attributes']['validation_messages']->has('remark'))
                                            <script>
                                                    document.getElementById('remark').className = 'form-control is-invalid';
                                            </script>
                                            <div class="invalid-feedback">{{ $ES['attributes']['validation_messages']->first("remark") }}</div>
                                        @endif
                                    </div>
                                    <div class="col-sm-1">
                                        <input type="submit" name="submit" id="submit" class="btn btn-primary btn-sm w-100" value="Save">
                                    </div>
                                </div>

                                <hr>

                            </div>

                            <div class="col-12 colmd-12">
                                <div class="table-responsive">
                                    <table class="table table-sm table-bordered">
                                        <thead>
                                            <tr>
                                                <th style="width: 5%; background-color: yellow;">#</th>
                                                <th style="width: 10%; background-color: yellow;">Date</th>
                                                <th style="width: 10%; background-color: yellow;" class="text-end">Gross Salary</th>
                                                <th style="width: 10%; background-color: yellow;" class="text-end">Advance</th>
                                                <th style="width: 10%; background-color: yellow;" class="text-end">OT Rate (For Hour)</th>
                                                <th style="width: 10%; background-color: yellow;" class="text-end">OT Hours</th>
                                                <th style="width: 10%; background-color: yellow;" class="text-end">OT Amounts</th>
                                                <th style="width: 10%; background-color: yellow;" class="text-end">Net Salary</th>
                                                <th style="width: 10%; background-color: yellow; text-align:center !important;">Pay</th>
                                            </tr>
                                        </thead>
                                        @if( count($ES['attributes']['salary_detail']) >= 1 )

                                            @php
                                                $date_serial = '19000101';
                                            @endphp

                                            <tbody>
                                                @foreach ($ES['attributes']['salary_detail'] as $rowValue)
                                                    <tr>
                                                        <td rowspan="2" style="width: 5%; vertical-align: middle; text-align:center;"><b>{{$rowValue['ono']}} </b> </td>
                                                        <td rowspan="2" style="width: 10%; vertical-align: middle; text-align:center;"><b>{{$rowValue['date']}} </b> </td>
                                                        <td style="width: 10%;" class="text-end">{{$rowValue['basic_salary']}}</td>
                                                        <td style="width: 10%;" class="text-end">{{$rowValue['advance_amount']}}</td>
                                                        <td style="width: 10%;" class="text-end">
                                                            <input type="text" name="ot_rate_{{$rowValue['date_serial']}}" id="ot_rate_{{$rowValue['date_serial']}}" class="form-control form-control-sm text-end" value="{{$rowValue['ot_rate']}}">
                                                        </td>
                                                        <td style="width: 10%;" class="text-end">
                                                            <input type="text" name="ot_hours_{{$rowValue['date_serial']}}" id="ot_hours_{{$rowValue['date_serial']}}" class="form-control form-control-sm text-end w-ot-hours" value="">
                                                            @if($ES['attributes']['validation_messages']->has('{{"ot_hours_". $date_serial }}'))
                                                                <script>
                                                                        document.getElementById("{{'ot_hours_' . $rowValue['date_serial']}}").className = 'form-select form-select-sm is-invalid';
                                                                </script>
                                                                <div class="invalid-feedback">{{ $ES['attributes']['validation_messages']->first("ot_hours_". $date_serial) }}</div>
                                                            @endif
                                                        </td>
                                                        <td style="width: 10%;" class="text-end">
                                                            <input type="text" name="ot_amount_{{$rowValue['date_serial']}}" id="ot_amount_{{$rowValue['date_serial']}}" class="form-control form-control-sm text-end" value="" readonly>
                                                            @if($ES['attributes']['validation_messages']->has('{{"ot_amount_". $date_serial }}'))
                                                                <script>
                                                                        document.getElementById("{{'ot_amount_' . $rowValue['date_serial']}}").className = 'form-select form-select-sm is-invalid';
                                                                </script>
                                                                <div class="invalid-feedback">{{ $ES['attributes']['validation_messages']->first("ot_amount_". $date_serial) }}</div>
                                                            @endif
                                                        </td>
                                                        <td style="width: 10%;" class="text-end">
                                                            <input type="text" name="net_salary_{{$rowValue['date_serial']}}" id="net_salary_{{$rowValue['date_serial']}}" class="form-control form-control-sm text-end" value="{{$rowValue['net_salary']}}" readonly>
                                                        </td>
                                                        <td rowspan="2" style="width: 10%; vertical-align: middle; text-align:center !important;" class="text-end">
                                                            <input type="checkbox" name="pay_{{$rowValue['date_serial']}}" id="pay_{{$rowValue['date_serial']}}" class="form-check-input" value="Pay">
                                                            <label class="form-check-label" for="flexCheckDefault">
                                                                Pay
                                                            </label>
                                                            @if($ES['attributes']['validation_messages']->has('{{"pay_". $date_serial }}'))
                                                                <script>
                                                                        document.getElementById("{{'pay_' . $rowValue['date_serial']}}").className = 'form-select form-select-sm is-invalid';
                                                                </script>
                                                                <div class="invalid-feedback">{{ $ES['attributes']['validation_messages']->first("pay_". $date_serial) }}</div>
                                                            @endif
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        @php
                                                            $date_serial = $rowValue['date_serial'];
                                                        @endphp

                                                        <td colspan="2" style="width: 25%;">
                                                            <select name="site_id_{{$rowValue['date_serial']}}" id="site_id_{{$rowValue['date_serial']}}" class="form-select form-select-sm w-site" >
                                                                @foreach($ES['site'] as $row)
                                                                    <option value ="{{$row->site_id}}">{{$row->site_name}}</option>
                                                                @endforeach
                                                                <option value ="0" selected>Select the Site </option>
                                                            </select>
                                                            @if($ES['attributes']['validation_messages']->has('{{"site_id_". $date_serial }}'))
                                                                <script>
                                                                        document.getElementById("{{'site_id_' . $rowValue['date_serial']}}").className = 'form-select form-select-sm is-invalid';
                                                                </script>
                                                                <div class="invalid-feedback">{{ $ES['attributes']['validation_messages']->first("site_id_". $date_serial) }}</div>
                                                            @endif
                                                        </td>
                                                        <td colspan="2" style="width: 25%;">
                                                            <select name="task_id_{{$rowValue['date_serial']}}" id="task_id_{{$rowValue['date_serial']}}" class="form-select form-select-sm w-task" >
                                                                <option value ="0" selected>Select the Task </option>
                                                            </select>
                                                            @if($ES['attributes']['validation_messages']->has('{{"task_id". $date_serial }}'))
                                                                <script>
                                                                        document.getElementById("{{'task_id' . $rowValue['date_serial']}}").className = 'form-select form-select-sm is-invalid';
                                                                </script>
                                                                <div class="invalid-feedback">{{ $ES['attributes']['validation_messages']->first("task_id". $date_serial) }}</div>
                                                            @endif
                                                        </td>
                                                        <td colspan="2" style="width: 25%;">
                                                            <select name="sub_task_id_{{$rowValue['date_serial']}}" id="sub_task_id_{{$rowValue['date_serial']}}" class="form-select form-select-sm" >
                                                                <option value ="0" selected>Select the Sub Task </option>
                                                            </select>
                                                            @if($ES['attributes']['validation_messages']->has('{{"sub_task_id". $date_serial }}'))
                                                                <script>
                                                                        document.getElementById("{{'sub_task_id' . $rowValue['date_serial']}}").className = 'form-select form-select-sm is-invalid';
                                                                </script>
                                                                <div class="invalid-feedback">{{ $ES['attributes']['validation_messages']->first("sub_task_id". $date_serial) }}</div>
                                                            @endif
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="9" style="background-color: green; height: 20px;"></td>
                                                    </tr>
                                                @endforeach
                                                <tr>
                                                    <td colspan="2"><b>Total </b></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td class="text-end"><strong>@money($ES['attributes']['pv_total'])</strong></td>
                                                    <td></td>
                                                </tr>
                                            </tbody>

                                        @else
                                            <tbody>
                                                <tr>
                                                    <td style="width: 5%;">-</td>
                                                    <td style="width: 20%;">-</td>
                                                    <td style="width: 10%;" class="text-end">0.00</td>
                                                    <td style="width: 10%;" class="text-end">0.00</td>
                                                    <td style="width: 15%;" class="text-end">0</td>
                                                    <td style="width: 10%;" class="text-end">0.00</td>
                                                    <td style="width: 10%;" class="text-end">0.00</td>
                                                    <td style="width: 15%;" class="text-end">0.00</td>
                                                </tr>
                                            </tbody>
                                        @endif
                                    </table>
                                  </div>

                            </div>

                        </div>

                    </div>
                </div>

            </form>
        </div>
    </div>

@endsection
