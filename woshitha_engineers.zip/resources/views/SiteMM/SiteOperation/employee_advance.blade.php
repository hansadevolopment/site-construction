@extends('layouts.site_monitoring')
@section('title')
    Employee Advance
@endsection
@section('body')

    <div class="row">
        <div class="col-12">
            <form method="POST" action="{{route('employee_advance_process')}}">
                @csrf

                <div class="card mt-3">

                    <div class="card-header">
                        Employee Advance
                    </div>

                    <div class="card-body">

                        <div class="row">
                            <div class="col-sm-12">
                                <?php echo $EA['attributes']['process_message'];  ?>
                            </div>
                        </div>

                        <div class="row no-gutters">
                            <div class="col-12 col-sm-12 col-md-12">


                                <div class="row mb-2">

                                    <div class="col-sm-9">
                                    </div>

                                    <label for="tid" class="col-sm-1 col-form-label-sm">PV No</label>
                                    <div class="col-sm-2">
                                        <input type="text" name="pv_id" id="pv_id" class="form-control form-control-sm" value="{{$EA['attributes']['pv_id']}}" readonly>
                                    </div>

                                </div>


                                <div class="row mb-2">

                                    <label for="tid" class="col-sm-1 col-form-label-sm">Employee</label>
                                    <div class="col-sm-5">
                                        <select name="employee_id" id="employee_id" class="form-select form-select-sm" >
                                            @foreach($EA['employee'] as $row)
                                                @if($EA['attributes']['employee_id'] == $row->employee_id)
                                                    <option value ="{{$row->employee_id}}" selected>{{$row->employee_name}}</option>
                                                @else
                                                    <option value ="{{$row->employee_id}}">{{$row->employee_name}}</option>
                                                @endif
                                            @endforeach
                                            @if($EA['attributes']['employee_id'] == "0")
                                                <option value ="0" selected>Select the Employee </option>
                                            @endif
                                        </select>
                                        @if($EA['attributes']['validation_messages']->has('employee_id'))
                                            <script>
                                                    document.getElementById('employee_id').className = 'form-select form-select-sm is-invalid';
                                            </script>
                                            <div class="invalid-feedback">{{ $EA['attributes']['validation_messages']->first("employee_id") }}</div>
                                        @endif
                                    </div>

                                    <div class="col-sm-3">
                                    </div>

                                    <label for="tid" class="col-sm-1 col-form-label-sm">PV Date</label>
                                    <div class="col-sm-2">
                                        <input type="date" name="pv_date" id="pv_date" class="form-control form-control-sm" value="{{$EA['attributes']['pv_date']}}">
                                    </div>

                                </div>

                                <div class="row mb-2">
                                    <label for="tid" class="col-sm-1 col-form-label-sm">Advance Amt</label>
                                    <div class="col-sm-2">
                                        <input type="text" name="advance_amount" id="advance_amount" class="form-control form-control-sm" value="">
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <label for="tid" class="col-sm-1 col-form-label-sm">Remark</label>
                                    <div class="col-sm-10">
                                        <input type="text" name="remark" id="remark" class="form-control form-control-sm" value="{{$EA['attributes']['remark']}}">
                                        @if($EA['attributes']['validation_messages']->has('remark'))
                                            <script>
                                                    document.getElementById('remark').className = 'form-control is-invalid';
                                            </script>
                                            <div class="invalid-feedback">{{ $EA['attributes']['validation_messages']->first("remark") }}</div>
                                        @endif
                                    </div>
                                    <div class="col-sm-1">
                                        <input type="submit" name="submit" id="submit" class="btn btn-success btn-sm w-100" value="Add">
                                    </div>
                                </div>

                                <div class="row mb-2">
                                    <div class="col-sm-1">
                                        <input type="reset" name="reset" id="reset" class="btn btn-primary btn-sm w-100" value="Reset">
                                    </div>
                                    <div class="col-sm-1">
                                        <input type="submit" name="submit" id="submit" class="btn btn-primary btn-sm w-100" value="Print">
                                    </div>
                                    <div class="col-sm-1">
                                        <input type="submit" name="submit" id="submit" class="btn btn-primary btn-sm w-100" value="Cancel">
                                    </div>
                                </div>
                                <hr>

                            </div>

                            <div class="col-12 colmd-12">
                                <div class="table-responsive">
                                    <table class="table table-sm table-bordered">
                                        <thead>
                                            <tr>
                                                <th style="width: 5%;">#</th>
                                                <th style="width: 85%;">Employee Name</th>
                                                <th style="width: 10%;" class="text-end">(Rs.) Amount</th>
                                            </tr>
                                        </thead>
                                        @if( count($EA['attributes']['pv_detail']) >= 1 )

                                            <tbody>
                                                @foreach ($EA['attributes']['pv_detail'] as $rowKey => $rowValue)
                                                    <tr>
                                                        <td style="width: 5%;">{{$rowValue->ono}}</td>
                                                        <td style="width: 85%;">{{$rowValue->employee_name}}</td>
                                                        <td style="width: 10%;" class="text-end">@money($rowValue->amount)</td>
                                                    </tr>
                                                @endforeach
                                                <tr>
                                                    <td colspan="2">Total</td>
                                                    <td class="text-end"><strong>@money($EA['attributes']['pv_total'])</strong></td>
                                                    <td></td>
                                                </tr>
                                            </tbody>

                                        @else
                                            <tbody>
                                                <tr>
                                                    <td style="width: 5%;">-</td>
                                                    <td style="width: 85%;">-</td>
                                                    <td style="width: 10%;" class="text-end">0.00</td>
                                                </tr>
                                            </tbody>
                                        @endif
                                    </table>
                                  </div>

                            </div>

                        </div>

                    </div>
                </div>

            </form>
        </div>
    </div>

@endsection
