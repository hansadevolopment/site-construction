@extends('layouts.site_monitoring')
@section('title')
    Site
@endsection
@section('body')

@endsection
